import * as THREE from 'three';

let pass = 0;
let fail = 0;
function check(name, cond, detail = '') {
  if (cond) pass++;
  else {
    fail++;
    console.log(`  FAIL  ${name}  ${detail}`);
  }
}

function reachableFromRoot(obj, root) {
  let found = false;
  root.traverse((o) => {
    if (o === obj) found = true;
  });
  return found;
}

console.log('=== Scene graph reachability ===');
console.log('(A renderer draws whatever it finds by traversing the scene root.');
console.log(' Something can be perfectly positioned and still never render if');
console.log(" it isn't actually reachable from that root. Regression test for");
console.log(' exactly that bug: the viewmodel hand was parented to the camera,');
console.log(' but the camera itself was never added to the scene.)');

{
  const scene = new THREE.Scene();
  const camera = new THREE.PerspectiveCamera();
  const rig = new THREE.Group();
  const weaponSlot = new THREE.Group();
  const handMesh = new THREE.Mesh(new THREE.BoxGeometry(1, 1, 1));
  camera.add(rig);
  rig.add(weaponSlot);
  weaponSlot.add(handMesh);

  const beforeFix = reachableFromRoot(handMesh, scene);
  console.log(`  (unfixed state would have hand reachable = ${beforeFix}, confirming this is a real reproducible bug)`);

  scene.add(camera); // the fix: main.js must do this

  check('camera is reachable by traversing the scene root', reachableFromRoot(camera, scene));
  check('viewmodel rig (child of camera) is reachable', reachableFromRoot(rig, scene));
  check('weapon slot (grandchild of camera) is reachable', reachableFromRoot(weaponSlot, scene));
  check('hand mesh (great-grandchild of camera) is reachable', reachableFromRoot(handMesh, scene));
}

console.log(`\n${pass} passed, ${fail} failed`);
if (fail > 0) process.exit(1);
