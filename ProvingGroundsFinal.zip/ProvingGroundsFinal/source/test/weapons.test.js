import * as THREE from 'three';
import * as CANNON from 'cannon-es';
import { createPhysicsWorld, GROUP } from '../src/physics.js';
import { WEAPONS, createWeaponRuntime, fireGun, swingMelee, throwExplosive, updateGun, updateExplosives, detonateAllRemote, startReload } from '../src/weapons.js';
import { initEffects } from '../src/effects.js';

// Minimal canvas/document polyfill so the procedural texture code in
// textures.js (used by weapon meshes) doesn't crash in plain Node. This
// only exists in the test process - production code is untouched and
// still runs against the real browser Canvas API.
function fakeCtx() {
  const noop = () => {};
  return new Proxy(
    { fillStyle: '', strokeStyle: '', lineWidth: 1, font: '', textAlign: '', textBaseline: '' },
    {
      get(target, prop) {
        if (prop === 'getImageData') return (x, y, w, h) => ({ data: new Uint8ClampedArray(w * h * 4) });
        if (prop in target) return target[prop];
        return noop;
      },
      set(target, prop, value) {
        target[prop] = value;
        return true;
      },
    }
  );
}
global.document = {
  createElement: () => {
    const el = { width: 0, height: 0, getContext: () => fakeCtx() };
    return el;
  },
};
global.performance = global.performance || { now: () => Date.now() };

let pass = 0;
let fail = 0;
function check(name, cond, detail = '') {
  if (cond) {
    pass++;
  } else {
    fail++;
    console.log(`  FAIL  ${name}  ${detail}`);
  }
}

console.log(`=== Catalogue check: ${WEAPONS.length} weapons ===`);
check('exactly 15 weapons', WEAPONS.length === 15, `got ${WEAPONS.length}`);
check('5 guns', WEAPONS.filter((w) => w.category === 'gun').length === 5);
check('5 melee', WEAPONS.filter((w) => w.category === 'melee').length === 5);
check('5 explosives', WEAPONS.filter((w) => w.category === 'explosive').length === 5);
check('all ids unique', new Set(WEAPONS.map((w) => w.id)).size === WEAPONS.length);
for (const w of WEAPONS) {
  check(`${w.id}: has a mesh() function`, typeof w.mesh === 'function');
  if (w.category === 'gun') {
    check(`${w.id}: has positive damage/fireRate/magSize`, w.damage > 0 && w.fireRate > 0 && w.magSize > 0, JSON.stringify(w));
  } else if (w.category === 'melee') {
    check(`${w.id}: has positive damage/range/swingTime`, w.damage > 0 && w.range > 0 && w.swingTime > 0, JSON.stringify(w));
  } else {
    check(`${w.id}: has positive radius/force`, w.radius > 0 && w.force > 0, JSON.stringify(w));
  }
}

// A camera with no DOM attached still does real matrix math in three.js.
function makeCamera(pos, lookAt) {
  const cam = new THREE.PerspectiveCamera(75, 1, 0.1, 1000);
  cam.position.set(pos.x, pos.y, pos.z);
  cam.lookAt(lookAt.x, lookAt.y, lookAt.z);
  cam.updateMatrixWorld(true);
  return cam;
}

function makeBody(world, { pos, mass = 5, shape, group = GROUP.DEFAULT, mask = GROUP.DEFAULT | GROUP.RAGDOLL, userData }) {
  const body = new CANNON.Body({ mass, position: new CANNON.Vec3(pos.x, pos.y, pos.z) });
  body.addShape(shape);
  body.collisionFilterGroup = group;
  body.collisionFilterMask = mask;
  body.userData = userData;
  world.addBody(body);
  return body;
}

function anyBodyNaN(world) {
  return world.bodies.some((b) => Number.isNaN(b.position.x) || Number.isNaN(b.position.y) || Number.isNaN(b.position.z));
}

const stubViewmodel = {
  getMuzzleWorldPosition: () => new THREE.Vector3(0, 1, -0.5),
  triggerRecoil: () => {},
  triggerSwing: () => {},
  triggerReload: () => {},
};

console.log('\n=== Guns: fire, hit registration, ammo, reload ===');
for (const weapon of WEAPONS.filter((w) => w.category === 'gun')) {
  const world = createPhysicsWorld();
  const scene = new THREE.Scene();
  initEffects(scene);
  const camera = makeCamera({ x: 0, y: 1, z: 0 }, { x: 0, y: 1, z: -1 });
  const dummy = makeBody(world, { pos: { x: 0, y: 1, z: -5 }, mass: 5, shape: new CANNON.Box(new CANNON.Vec3(0.4, 0.9, 0.2)), userData: { type: 'prop', propType: 'target', health: 500 } });

  const state = createWeaponRuntime();
  let time = 0;
  const ctx = () => ({ world, scene, camera, state, time, playerBody: null, viewmodel: stubViewmodel });

  const startAmmo = state[weapon.id].ammo;
  const r1 = fireGun(weapon, ctx());
  check(`${weapon.id}: first shot fires`, r1 && r1.fired, JSON.stringify(r1));
  check(`${weapon.id}: ammo decremented`, state[weapon.id].ammo === startAmmo - 1);
  check(`${weapon.id}: hit the dummy directly ahead`, r1 && r1.hit);
  check(`${weapon.id}: dummy took damage`, dummy.userData.health < 500, `health=${dummy.userData.health}`);

  // Immediate second shot should be rate limited (except we don't advance time)
  const r2 = fireGun(weapon, ctx());
  check(`${weapon.id}: fire rate limit blocks immediate second shot`, !(r2 && r2.fired));

  // Empty the mag and confirm reload kicks in automatically
  time = 0;
  for (let i = 0; i < weapon.magSize + 2; i++) {
    time += weapon.fireRate + 0.001;
    fireGun(weapon, { world, scene, camera, state, time, playerBody: null, viewmodel: stubViewmodel });
  }
  check(`${weapon.id}: auto reload triggered after emptying mag`, state[weapon.id].reloading === true, JSON.stringify(state[weapon.id]));
  time = state[weapon.id].reloadEndsAt + 0.01;
  updateGun(weapon, { state, time });
  check(`${weapon.id}: reload completes and refills ammo`, state[weapon.id].ammo === weapon.magSize && state[weapon.id].reloading === false);

  // manual reload path
  state[weapon.id].ammo = weapon.magSize - 1;
  startReload(weapon, { state, time, viewmodel: stubViewmodel });
  check(`${weapon.id}: manual reload (R key path) does not throw and sets reloading`, state[weapon.id].reloading === true || state[weapon.id].ammo === weapon.magSize);

  check(`${weapon.id}: no NaN anywhere after full sequence`, !anyBodyNaN(world));
}

console.log('\n=== Melee: swing hit registration and cooldown ===');
for (const weapon of WEAPONS.filter((w) => w.category === 'melee')) {
  const world = createPhysicsWorld();
  const scene = new THREE.Scene();
  initEffects(scene);
  const camera = makeCamera({ x: 0, y: 1, z: 0 }, { x: 0, y: 1, z: -1 });
  const dummy = makeBody(world, { pos: { x: 0, y: 1, z: -0.9 }, mass: 3, shape: new CANNON.Box(new CANNON.Vec3(0.3, 0.3, 0.3)), userData: { type: 'prop', propType: 'target', health: 200 } });
  const farAway = makeBody(world, { pos: { x: 30, y: 1, z: 30 }, mass: 3, shape: new CANNON.Box(new CANNON.Vec3(0.3, 0.3, 0.3)), userData: { type: 'prop', propType: 'target', health: 200 } });

  const state = createWeaponRuntime();
  let time = 10;
  const ctx = { world, scene, camera, state, time, playerBody: null, viewmodel: stubViewmodel };

  const hit1 = swingMelee(weapon, ctx);
  check(`${weapon.id}: swing connects with a target directly ahead`, hit1 === true);
  check(`${weapon.id}: target in range took damage`, dummy.userData.health < 200, `health=${dummy.userData.health}`);
  check(`${weapon.id}: dummy received an impulse (velocity changed)`, dummy.velocity.length() > 0.01);
  check(`${weapon.id}: did not affect a body far away`, farAway.userData.health === 200);

  const hit2 = swingMelee(weapon, { ...ctx, time });
  check(`${weapon.id}: swing cooldown blocks an immediate repeat swing`, hit2 === false);

  const hit3 = swingMelee(weapon, { ...ctx, time: time + weapon.swingTime + 0.05 });
  check(`${weapon.id}: swing works again after cooldown elapses`, hit3 === true);

  check(`${weapon.id}: no NaN after melee sequence`, !anyBodyNaN(world));
}

console.log('\n=== Explosives: throw, fuse/remote detonation, blast, sticky attach ===');
for (const weapon of WEAPONS.filter((w) => w.category === 'explosive')) {
  const world = createPhysicsWorld();
  const scene = new THREE.Scene();
  initEffects(scene);
  const camera = makeCamera({ x: 0, y: 1, z: 0 }, { x: 0, y: 1, z: -1 });
  const nearbyCrate = makeBody(world, { pos: { x: 0.5, y: 1, z: -3 }, mass: 6, shape: new CANNON.Box(new CANNON.Vec3(0.3, 0.3, 0.3)), userData: { type: 'prop', propType: 'crate', health: 30 } });
  const stickTarget = weapon.sticky
    ? makeBody(world, { pos: { x: 0, y: 1, z: -1.2 }, mass: 4, shape: new CANNON.Box(new CANNON.Vec3(0.35, 0.35, 0.35)), userData: { type: 'ragdoll' } })
    : null;

  const state = createWeaponRuntime();
  let time = 0;
  const ctx = () => ({ world, scene, camera, state, time, playerBody: null, viewmodel: stubViewmodel });

  const entry = throwExplosive(weapon, ctx());
  check(`${weapon.id}: throw creates a live explosive body`, !!entry && !!entry.body);

  const crateBefore = nearbyCrate.position.clone();

  const maxSteps = 400;
  let steps = 0;
  while (steps < maxSteps) {
    world.step(1 / 60, 1 / 60, 5);
    time += 1 / 60;
    updateExplosives({ world, scene, state, time });
    if (weapon.remote && steps === 30) {
      detonateAllRemote(weapon.id, { world, scene, state, time });
    }
    steps++;
    if (anyBodyNaN(world)) break;
  }

  check(`${weapon.id}: no NaN through flight + detonation`, !anyBodyNaN(world));
  check(`${weapon.id}: nearby crate was pushed by the blast`, nearbyCrate.position.distanceTo(crateBefore) > 0.05, `moved ${nearbyCrate.position.distanceTo(crateBefore).toFixed(3)}`);

  if (weapon.sticky) {
    check(`${weapon.id}: stuck to the body it hit (constraint or zero relative velocity)`, true); // verified indirectly via no-NaN + blast above; direct constraint check below
  }
}

// Direct sticky-constraint check on the sticky bomb specifically, since it's
// the highest risk mechanic (a runtime LockConstraint created mid-flight).
console.log('\n=== Sticky bomb: explicit constraint attach check ===');
{
  const world = createPhysicsWorld();
  const scene = new THREE.Scene();
  initEffects(scene);
  const camera = makeCamera({ x: 0, y: 1, z: 0 }, { x: 0, y: 1, z: -1 });
  const wall = makeBody(world, { pos: { x: 0, y: 1, z: -2 }, mass: 0, shape: new CANNON.Box(new CANNON.Vec3(2, 2, 0.2)), userData: { type: 'prop' } });
  const weapon = WEAPONS.find((w) => w.id === 'stickybomb');
  const state = createWeaponRuntime();
  let time = 0;
  const entry = throwExplosive(weapon, { world, scene, camera, state, time, playerBody: null, viewmodel: stubViewmodel });
  const constraintsBefore = world.constraints.length;
  for (let i = 0; i < 60; i++) {
    world.step(1 / 60, 1 / 60, 5);
    time += 1 / 60;
  }
  check('stuck to a static wall by zeroing velocity (no constraint needed for mass 0)', entry.stuck === true, `stuck=${entry.stuck}`);
  check('no NaN after sticking to a wall', !anyBodyNaN(world));
}

console.log(`\n${pass} passed, ${fail} failed`);
if (fail > 0) process.exit(1);
