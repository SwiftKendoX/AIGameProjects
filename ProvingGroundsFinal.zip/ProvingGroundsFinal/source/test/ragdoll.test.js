import * as CANNON from 'cannon-es';
import { createPhysicsWorld, GROUP, applyExplosionForce } from '../src/physics.js';
import { createRagdoll } from '../src/ragdoll.js';

let pass = 0;
let fail = 0;
function check(name, cond, detail = '') {
  if (cond) {
    pass++;
    console.log(`  PASS  ${name}`);
  } else {
    fail++;
    console.log(`  FAIL  ${name}  ${detail}`);
  }
}

function addGround(world) {
  const ground = new CANNON.Body({ mass: 0 });
  ground.addShape(new CANNON.Plane());
  ground.quaternion.setFromEuler(-Math.PI / 2, 0, 0);
  ground.collisionFilterGroup = GROUP.DEFAULT;
  ground.collisionFilterMask = GROUP.DEFAULT | GROUP.RAGDOLL;
  world.addBody(ground);
  return ground;
}

function maxPairwiseSpread(bodies) {
  let max = 0;
  for (let i = 0; i < bodies.length; i++) {
    for (let j = i + 1; j < bodies.length; j++) {
      const d = bodies[i].position.distanceTo(bodies[j].position);
      if (d > max) max = d;
    }
  }
  return max;
}

function anyNaN(bodies) {
  return bodies.some(
    (b) =>
      Number.isNaN(b.position.x) ||
      Number.isNaN(b.position.y) ||
      Number.isNaN(b.position.z) ||
      Number.isNaN(b.velocity.x) ||
      Number.isNaN(b.velocity.y) ||
      Number.isNaN(b.velocity.z)
  );
}

console.log('=== Test 1: ragdoll dropped from height settles without exploding ===');
{
  const world = createPhysicsWorld();
  addGround(world);
  const rag = createRagdoll(world, new CANNON.Vec3(0, 3, 0));
  check('ragdoll has 11 body parts', rag.bodies.length === 11, `got ${rag.bodies.length}`);
  check('ragdoll has 10 constraints', rag.constraints.length === 10, `got ${rag.constraints.length}`);

  const spreadBefore = maxPairwiseSpread(rag.bodies);

  for (let i = 0; i < 600; i++) {
    world.step(1 / 60, 1 / 60, 5);
    if (anyNaN(rag.bodies)) break;
  }

  check('no NaN after 10s simulated', !anyNaN(rag.bodies));
  const spreadAfter = maxPairwiseSpread(rag.bodies);
  check(
    'body parts stayed close together (no self destruct)',
    spreadAfter < 2.2,
    `max spread ${spreadAfter.toFixed(2)}m (was ${spreadBefore.toFixed(2)}m at spawn)`
  );

  const lowestY = Math.min(...rag.bodies.map((b) => b.position.y));
  check('ragdoll actually fell and landed near the ground', lowestY < 1.0 && lowestY > -0.5, `lowest part y=${lowestY.toFixed(2)}`);

  const avgSpeed = rag.bodies.reduce((s, b) => s + b.velocity.length(), 0) / rag.bodies.length;
  check('ragdoll came to rest (low residual velocity)', avgSpeed < 0.6, `avg speed ${avgSpeed.toFixed(2)} m/s`);
}

console.log('=== Test 2: two ragdolls do not collide with each other or self collide when overlapped ===');
{
  const world = createPhysicsWorld();
  addGround(world);
  const ragA = createRagdoll(world, new CANNON.Vec3(0, 3, 0));
  const ragB = createRagdoll(world, new CANNON.Vec3(0.05, 3.05, 0)); // deliberately overlapping spawn
  for (let i = 0; i < 300; i++) world.step(1 / 60, 1 / 60, 5);
  check('no NaN with two overlapping ragdolls', !anyNaN(ragA.bodies) && !anyNaN(ragB.bodies));
  const allBodies = [...ragA.bodies, ...ragB.bodies];
  const spread = maxPairwiseSpread(allBodies);
  check('overlapping spawn did not cause an explosive separation', spread < 6, `max spread ${spread.toFixed(2)}m`);
}

console.log('=== Test 3: explosion force launches ragdoll outward and it survives ===');
{
  const world = createPhysicsWorld();
  addGround(world);
  const rag = createRagdoll(world, new CANNON.Vec3(0, 1.05, 0));
  for (let i = 0; i < 120; i++) world.step(1 / 60, 1 / 60, 5); // let it settle standing-ish first
  const torsoBefore = rag.parts.torso.position.clone();
  const affected = applyExplosionForce(world, new CANNON.Vec3(0, 0.5, -1), 5, 14);
  check('explosion registered affected bodies', affected.length > 0, `${affected.length} bodies affected`);
  for (let i = 0; i < 180; i++) world.step(1 / 60, 1 / 60, 5);
  check('no NaN after explosion', !anyNaN(rag.bodies));
  const torsoAfter = rag.parts.torso.position;
  const moved = torsoBefore.distanceTo(torsoAfter);
  check('ragdoll was actually displaced by the blast', moved > 0.3, `moved ${moved.toFixed(2)}m`);
  const spread = maxPairwiseSpread(rag.bodies);
  check('ragdoll stayed intact after explosion (limbs did not fly apart)', spread < 2.5, `max spread ${spread.toFixed(2)}m`);
}

console.log('=== Test 4: plain dynamic props survive a nearby explosion ===');
{
  const world = createPhysicsWorld();
  addGround(world);
  const crate = new CANNON.Body({ mass: 5, position: new CANNON.Vec3(1, 1, 0) });
  crate.addShape(new CANNON.Box(new CANNON.Vec3(0.4, 0.4, 0.4)));
  world.addBody(crate);
  applyExplosionForce(world, new CANNON.Vec3(0, 0.5, 0), 6, 10);
  for (let i = 0; i < 120; i++) world.step(1 / 60, 1 / 60, 5);
  check('crate has no NaN after blast', !Number.isNaN(crate.position.x));
  check('crate was pushed away from blast center', crate.position.x > 1.0, `x=${crate.position.x.toFixed(2)}`);
}

console.log(`\n${pass} passed, ${fail} failed`);
if (fail > 0) process.exit(1);
