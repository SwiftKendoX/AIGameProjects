import * as THREE from 'three';
import { createViewmodel } from '../src/viewmodel.js';
import { WEAPONS } from '../src/weapons.js';

global.performance = global.performance || { now: () => Date.now() };
// Minimal canvas polyfill, same as weapons.test.js, since weapon meshes use
// procedural textures.
function fakeCtx() {
  const noop = () => {};
  return new Proxy(
    { fillStyle: '', strokeStyle: '', lineWidth: 1, font: '', textAlign: '', textBaseline: '' },
    {
      get(target, prop) {
        if (prop === 'getImageData') return (x, y, w, h) => ({ data: new Uint8ClampedArray(w * h * 4) });
        if (prop in target) return target[prop];
        return noop;
      },
      set(target, prop, value) {
        target[prop] = value;
        return true;
      },
    }
  );
}
global.document = { createElement: () => ({ width: 0, height: 0, getContext: () => fakeCtx() }) };

let pass = 0;
let fail = 0;
function check(name, cond, detail = '') {
  if (cond) pass++;
  else {
    fail++;
    console.log(`  FAIL  ${name}  ${detail}`);
  }
}

console.log('=== Aim down sights: transitions and hides correctly ===');
{
  const camera = new THREE.PerspectiveCamera();
  const vm = createViewmodel(camera);
  vm.setWeapon(WEAPONS.find((w) => w.id === 'pistol'));

  const restX = vm.group.position.x;
  vm.update(1 / 60, {});
  check('starts at hip-fire position (not centered)', Math.abs(vm.group.position.x) > 0.1, `x=${vm.group.position.x.toFixed(3)}`);

  vm.setAiming(true);
  for (let i = 0; i < 60; i++) vm.update(1 / 60, {}); // 1 second, plenty to converge
  check('moves toward centered position once aiming', Math.abs(vm.group.position.x) < 0.05, `x=${vm.group.position.x.toFixed(3)}`);

  vm.setAiming(false);
  for (let i = 0; i < 60; i++) vm.update(1 / 60, {});
  check('returns to hip-fire position once no longer aiming', Math.abs(vm.group.position.x - restX) < 0.02, `x=${vm.group.position.x.toFixed(3)}`);

  check('rig is visible by default', vm.group.visible === true);
  vm.setHidden(true);
  check('rig hides for scope mode', vm.group.visible === false);
  vm.setHidden(false);
  check('rig un-hides again', vm.group.visible === true);
}

console.log('\n=== Switching weapons resets aim state cleanly ===');
{
  const camera = new THREE.PerspectiveCamera();
  const vm = createViewmodel(camera);
  vm.setWeapon(WEAPONS.find((w) => w.id === 'sniper'));
  vm.setAiming(true);
  for (let i = 0; i < 60; i++) vm.update(1 / 60, {});
  const aimedX = vm.group.position.x;
  check('was aiming (centered)', Math.abs(aimedX) < 0.05, `x=${aimedX.toFixed(3)}`);

  vm.setWeapon(WEAPONS.find((w) => w.id === 'pistol'));
  vm.update(1 / 60, {});
  check('switching weapons snaps back to hip-fire immediately, not stuck aiming', Math.abs(vm.group.position.x) > 0.1, `x=${vm.group.position.x.toFixed(3)}`);
}

console.log(`\n${pass} passed, ${fail} failed`);
if (fail > 0) process.exit(1);
