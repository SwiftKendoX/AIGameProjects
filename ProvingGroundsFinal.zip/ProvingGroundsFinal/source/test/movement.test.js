import * as CANNON from 'cannon-es';
import { createPhysicsWorld, GROUP, defaultMaterial, playerMaterial } from '../src/physics.js';

let pass = 0;
let fail = 0;
function check(name, cond, detail = '') {
  if (cond) pass++;
  else {
    fail++;
    console.log(`  FAIL  ${name}  ${detail}`);
  }
}

const WALK_SPEED = 4.2;
const SPRINT_SPEED = 4.2 * 1.55;

function buildGroundAndPlayer(world) {
  const ground = new CANNON.Body({ mass: 0, material: defaultMaterial });
  ground.addShape(new CANNON.Plane());
  ground.quaternion.setFromEuler(-Math.PI / 2, 0, 0);
  ground.collisionFilterGroup = GROUP.DEFAULT;
  ground.collisionFilterMask = GROUP.DEFAULT | GROUP.RAGDOLL | GROUP.PLAYER;
  world.addBody(ground);

  const player = new CANNON.Body({
    mass: 70,
    position: new CANNON.Vec3(0, 3, 0),
    fixedRotation: true,
    linearDamping: 0.05,
    material: playerMaterial,
  });
  player.addShape(new CANNON.Sphere(0.4));
  player.collisionFilterGroup = GROUP.PLAYER;
  player.collisionFilterMask = GROUP.DEFAULT | GROUP.RAGDOLL;
  world.addBody(player);
  return { ground, player };
}

console.log('=== Movement: player reaches real walk/sprint speed against ground friction ===');
{
  const world = createPhysicsWorld();
  const { player } = buildGroundAndPlayer(world);

  for (let i = 0; i < 200; i++) world.step(1 / 60, 1 / 60, 5); // settle onto the ground

  for (let i = 0; i < 90; i++) {
    world.step(1 / 60, 1 / 60, 5);
    player.velocity.x += (WALK_SPEED - player.velocity.x) * 0.32;
  }
  check(
    `player reaches at least 90% of intended walk speed (${WALK_SPEED} u/s) while grounded`,
    player.velocity.x > WALK_SPEED * 0.9,
    `got vx=${player.velocity.x.toFixed(2)}, expected close to ${WALK_SPEED}`
  );
  check('player did not sink into or pop off the ground while accelerating', Math.abs(player.position.y - 0.4) < 0.05, `y=${player.position.y.toFixed(3)}`);
}

console.log('=== Movement: sprint speed also converges correctly ===');
{
  const world = createPhysicsWorld();
  const { player } = buildGroundAndPlayer(world);
  for (let i = 0; i < 200; i++) world.step(1 / 60, 1 / 60, 5);
  for (let i = 0; i < 90; i++) {
    world.step(1 / 60, 1 / 60, 5);
    player.velocity.z += (SPRINT_SPEED - player.velocity.z) * 0.32;
  }
  check(`player reaches at least 90% of sprint speed (${SPRINT_SPEED.toFixed(1)} u/s)`, player.velocity.z > SPRINT_SPEED * 0.9, `got vz=${player.velocity.z.toFixed(2)}`);
}

console.log('=== Movement: everything else keeps normal friction (props still settle, do not slide forever) ===');
{
  const world = createPhysicsWorld();
  const { player } = buildGroundAndPlayer(world);
  const crate = new CANNON.Body({ mass: 5, position: new CANNON.Vec3(0, 1, 0), material: defaultMaterial });
  crate.addShape(new CANNON.Box(new CANNON.Vec3(0.3, 0.3, 0.3)));
  crate.velocity.set(3, 0, 0);
  world.addBody(crate);
  for (let i = 0; i < 300; i++) world.step(1 / 60, 1 / 60, 5);
  check('a sliding crate (unrelated to the player) still slows down under normal friction', crate.velocity.length() < 0.5, `residual speed=${crate.velocity.length().toFixed(2)}`);
}

console.log('=== Movement: convergence to target speed is frame-rate independent ===');
{
  // Same formula player.js actually uses now. Reproduced here (rather
  // than imported) only because it's a few lines of pure math with no
  // physics/DOM dependency worth its own export; the constants are kept
  // in sync with player.js's RESPONSE_RATE_GROUNDED.
  const RATE = 23;
  function converge(totalTime, dt) {
    let v = 0;
    const target = WALK_SPEED;
    const steps = Math.round(totalTime / dt);
    for (let i = 0; i < steps; i++) {
      const factor = 1 - Math.exp(-RATE * dt);
      v += (target - v) * factor;
    }
    return v;
  }
  const at60 = converge(0.5, 1 / 60);
  const at15 = converge(0.5, 1 / 15);
  const at5 = converge(0.5, 1 / 5);
  check('reaches walk speed the same way at 60fps', at60 > WALK_SPEED * 0.95, `${at60.toFixed(2)}`);
  check('reaches walk speed the same way at 15fps (degraded)', at15 > WALK_SPEED * 0.95, `${at15.toFixed(2)}`);
  check('reaches walk speed the same way at 5fps (badly degraded)', at5 > WALK_SPEED * 0.95, `${at5.toFixed(2)}`);
}

console.log(`\n${pass} passed, ${fail} failed`);
if (fail > 0) process.exit(1);
