import * as THREE from 'three';
import * as CANNON from 'cannon-es';
import { createPhysicsWorld, GROUP, defaultMaterial, applyExplosionForce } from '../src/physics.js';
import { createDummy, damageDummy, updateDummy, findDummyByBody, removeDummy, allDummies, MAX_HEALTH } from '../src/dummy.js';
import { createRagdoll } from '../src/ragdoll.js';

let pass = 0;
let fail = 0;
function check(name, cond, detail = '') {
  if (cond) pass++;
  else {
    fail++;
    console.log(`  FAIL  ${name}  ${detail}`);
  }
}

function addGround(world) {
  const ground = new CANNON.Body({ mass: 0, material: defaultMaterial });
  ground.addShape(new CANNON.Plane());
  ground.quaternion.setFromEuler(-Math.PI / 2, 0, 0);
  ground.collisionFilterGroup = GROUP.DEFAULT;
  ground.collisionFilterMask = GROUP.DEFAULT | GROUP.RAGDOLL;
  world.addBody(ground);
}

function anyNaN(bodies) {
  return bodies.some((b) => Number.isNaN(b.position.x) || Number.isNaN(b.position.y) || Number.isNaN(b.position.z));
}

function run(world, dummy, seconds, time) {
  const steps = Math.round(seconds * 60);
  for (let i = 0; i < steps; i++) {
    world.step(1 / 60, 1 / 60, 5);
    time += 1 / 60;
    updateDummy(dummy, time);
  }
  return time;
}

console.log('=== A freshly spawned dummy stays standing on its own (assist holds the pose) ===');
{
  const world = createPhysicsWorld();
  addGround(world);
  const scene = new THREE.Scene();
  const dummy = createDummy(world, scene, new CANNON.Vec3(0, 1.02, 0));
  let time = 0;
  time = run(world, dummy, 4, time);
  check('no NaN while standing idle', !anyNaN(dummy.ragdoll.bodies));
  const pelvisY = dummy.ragdoll.parts.pelvis.position.y;
  check('pelvis stayed near standing height instead of collapsing', pelvisY > 0.55, `pelvis y=${pelvisY.toFixed(2)}`);
  const headY = dummy.ragdoll.parts.head.position.y;
  check('head stayed high (dummy did not fall over)', headY > 1.2, `head y=${headY.toFixed(2)}`);

  time = run(world, dummy, 3, time);
  const wobble = dummy.ragdoll.parts.torso.angularVelocity.length() + dummy.ragdoll.parts.pelvis.velocity.length();
  check('standing assist settles down rather than jittering indefinitely', wobble < 0.6, `residual motion=${wobble.toFixed(2)}`);
}

console.log('\n=== A hit immediately ragdolls it with zero assist interference ===');
{
  const world = createPhysicsWorld();
  addGround(world);
  const scene = new THREE.Scene();
  const dummy = createDummy(world, scene, new CANNON.Vec3(0, 1.02, 0));
  let time = 0;
  time = run(world, dummy, 2, time); // let it settle standing first
  const headYBefore = dummy.ragdoll.parts.head.position.y;

  damageDummy(dummy, 40, time);
  dummy.ragdoll.parts.torso.applyImpulse(new CANNON.Vec3(0, 0, 9), dummy.ragdoll.parts.torso.position);

  // Simulate for less than the recovery delay: it should be down and NOT
  // being actively pulled back up yet.
  time = run(world, dummy, 1.0, time);
  check('health reduced by the hit', dummy.health === MAX_HEALTH - 40, `health=${dummy.health}`);
  check('dummy actually fell (head dropped well below standing height)', dummy.ragdoll.parts.head.position.y < headYBefore - 0.4, `head y=${dummy.ragdoll.parts.head.position.y.toFixed(2)}`);
  check('no NaN through the knockdown', !anyNaN(dummy.ragdoll.bodies));
}

console.log('\n=== After settling, a living dummy stands back up on its own ===');
{
  const world = createPhysicsWorld();
  addGround(world);
  const scene = new THREE.Scene();
  const dummy = createDummy(world, scene, new CANNON.Vec3(0, 1.02, 0));
  let time = 0;
  time = run(world, dummy, 2, time);

  damageDummy(dummy, 30, time);
  dummy.ragdoll.parts.torso.applyImpulse(new CANNON.Vec3(2, 1, 6), dummy.ragdoll.parts.torso.position);
  time = run(world, dummy, 1.5, time); // falls

  const downHeadY = dummy.ragdoll.parts.head.position.y;
  time = run(world, dummy, 7, time); // past the recovery delay, long enough to recover

  const upHeadY = dummy.ragdoll.parts.head.position.y;
  check('still alive', !dummy.dead, `health=${dummy.health}`);
  check('head rose back up significantly after the recovery window', upHeadY > downHeadY + 0.5, `down=${downHeadY.toFixed(2)} up=${upHeadY.toFixed(2)}`);
  check('pelvis is back near standing height', dummy.ragdoll.parts.pelvis.position.y > 0.55, `pelvis y=${dummy.ragdoll.parts.pelvis.position.y.toFixed(2)}`);
  check('no NaN through the full knockdown+recovery cycle', !anyNaN(dummy.ragdoll.bodies));
}

console.log('\n=== A dead dummy (health depleted) never stands back up ===');
{
  const world = createPhysicsWorld();
  addGround(world);
  const scene = new THREE.Scene();
  const dummy = createDummy(world, scene, new CANNON.Vec3(0, 1.02, 0));
  let time = 0;
  time = run(world, dummy, 2, time);

  damageDummy(dummy, MAX_HEALTH, time); // lethal hit
  dummy.ragdoll.parts.torso.applyImpulse(new CANNON.Vec3(1, 1, 5), dummy.ragdoll.parts.torso.position);
  check('dummy is dead', dummy.dead);
  time = run(world, dummy, 1.5, time);
  const downHeadY = dummy.ragdoll.parts.head.position.y;
  time = run(world, dummy, 8, time); // well past the recovery delay
  const laterHeadY = dummy.ragdoll.parts.head.position.y;
  check('a dead dummy stays down instead of recovering', laterHeadY < downHeadY + 0.35, `down=${downHeadY.toFixed(2)} later=${laterHeadY.toFixed(2)}`);
  check('no NaN for a dead dummy left lying around', !anyNaN(dummy.ragdoll.bodies));
}

console.log('\n=== findDummyByBody resolves any hit part back to its owning dummy ===');
{
  const world = createPhysicsWorld();
  addGround(world);
  const scene = new THREE.Scene();
  const dummy = createDummy(world, scene, new CANNON.Vec3(0, 1.02, 0));
  const found = findDummyByBody(dummy.ragdoll.parts.lowerArmR);
  check('a hit on an arm resolves back to the same dummy object', found === dummy);
  const unrelated = new CANNON.Body({ mass: 1 });
  check('a body with no ragdoll tag resolves to null, not a crash', findDummyByBody(unrelated) === null);
}

console.log('\n=== removeDummy cleans up fully ===');
{
  const world = createPhysicsWorld();
  addGround(world);
  const scene = new THREE.Scene();
  const dummy = createDummy(world, scene, new CANNON.Vec3(0, 1.02, 0));
  const bodyCountBefore = world.bodies.length;
  const constraintCountBefore = world.constraints.length;
  removeDummy(world, scene, dummy);
  check('all 11 ragdoll bodies removed from the world', world.bodies.length === bodyCountBefore - 11, `${world.bodies.length} vs expected ${bodyCountBefore - 11}`);
  check('all 10 constraints removed from the world', world.constraints.length === constraintCountBefore - 10, `${world.constraints.length} vs expected ${constraintCountBefore - 10}`);
  check('no longer resolvable by findDummyByBody', findDummyByBody(dummy.ragdoll.parts.head) === null);
}

console.log('\n=== A hard cap prevents unbounded dummy spam (evicts the oldest) ===');
{
  const world = createPhysicsWorld();
  addGround(world);
  const scene = new THREE.Scene();
  const first = createDummy(world, scene, new CANNON.Vec3(0, 1.02, 0));
  for (let i = 1; i < 15; i++) createDummy(world, scene, new CANNON.Vec3(i * 0.01, 1.02, 0));
  check('registry never exceeds the cap even after spawning 15', allDummies().length <= 10, `count=${allDummies().length}`);
  check('the oldest dummy was evicted, not still findable', findDummyByBody(first.ragdoll.parts.head) === null);
  check('no NaN anywhere after repeated spawn/evict', !anyNaN(world.bodies));
}

console.log('\n=== A standing dummy is not anchored: pushing it moves it about as much as a plain ragdoll would ===');
{
  // Baseline: the exact same push against a raw ragdoll with zero assist
  // force involved anywhere, to know what this impulse actually does on
  // its own before comparing.
  const baseWorld = createPhysicsWorld();
  addGround(baseWorld);
  const rawRagdoll = createRagdoll(baseWorld, new CANNON.Vec3(0, 1.02, 0));
  for (let i = 0; i < 240; i++) baseWorld.step(1 / 60, 1 / 60, 5);
  const baseBefore = rawRagdoll.parts.pelvis.position.clone();
  rawRagdoll.parts.pelvis.applyImpulse(new CANNON.Vec3(0, 0, 9), rawRagdoll.parts.pelvis.position);
  for (let i = 0; i < 30; i++) baseWorld.step(1 / 60, 1 / 60, 5); // 0.5s
  const baselineDisplacement = rawRagdoll.parts.pelvis.position.distanceTo(baseBefore);

  const world = createPhysicsWorld();
  addGround(world);
  const scene = new THREE.Scene();
  const dummy = createDummy(world, scene, new CANNON.Vec3(0, 1.02, 0));
  let time = 0;
  time = run(world, dummy, 4, time); // let it settle standing, assist should now be idle (deadzone)

  const torqueBefore = dummy.ragdoll.parts.torso.torque.clone();
  check('assist applies no force once already standing (deadzone)', torqueBefore.length() < 0.01, `torque=${torqueBefore.length().toFixed(3)}`);

  const pelvisBefore = dummy.ragdoll.parts.pelvis.position.clone();
  // Same impulse as the baseline above, NOT a weapon hit (damageDummy is
  // never called), same as just walking into it.
  dummy.ragdoll.parts.pelvis.applyImpulse(new CANNON.Vec3(0, 0, 9), dummy.ragdoll.parts.pelvis.position);
  time = run(world, dummy, 0.5, time);
  const withAssistDisplacement = dummy.ragdoll.parts.pelvis.position.distanceTo(pelvisBefore);

  check(
    'the push moves it about as much as it would with no assist at all (not fought back)',
    withAssistDisplacement > baselineDisplacement * 0.6,
    `baseline(no assist)=${baselineDisplacement.toFixed(3)}m, with assist=${withAssistDisplacement.toFixed(3)}m`
  );

  // It should still recover given enough time, same as being knocked down
  // by a weapon - "not anchored while standing" should not mean "never
  // gets back up".
  time = run(world, dummy, 8, time);
  check('it still stands back up on its own eventually after a plain push', dummy.ragdoll.parts.pelvis.position.y > 0.7, `pelvis y=${dummy.ragdoll.parts.pelvis.position.y.toFixed(2)}`);
}

console.log(`\n${pass} passed, ${fail} failed`);
if (fail > 0) process.exit(1);
