import * as THREE from 'three';
import * as CANNON from 'cannon-es';
import { createPhysicsWorld, GROUP, defaultMaterial } from '../src/physics.js';
import { SPAWNERS, trySpawn, spawnedPropCount } from '../src/spawners.js';
import { allDummies } from '../src/dummy.js';
import { allSynced } from '../src/props.js';

// Same DOM-free canvas polyfill as weapons.test.js, needed because
// props.js's crate/barrel/plank/target all use procedural canvas textures.
function fakeCtx() {
  const noop = () => {};
  return new Proxy(
    { fillStyle: '', strokeStyle: '', lineWidth: 1, font: '', textAlign: '', textBaseline: '' },
    {
      get(target, prop) {
        if (prop === 'getImageData') return (x, y, w, h) => ({ data: new Uint8ClampedArray(w * h * 4) });
        if (prop in target) return target[prop];
        return noop;
      },
      set(target, prop, value) {
        target[prop] = value;
        return true;
      },
    }
  );
}
global.document = { createElement: () => ({ width: 0, height: 0, getContext: () => fakeCtx() }) };

let pass = 0;
let fail = 0;
function check(name, cond, detail = '') {
  if (cond) pass++;
  else {
    fail++;
    console.log(`  FAIL  ${name}  ${detail}`);
  }
}

function makeCamera(pos, lookAt) {
  const cam = new THREE.PerspectiveCamera(75, 1, 0.1, 1000);
  cam.position.set(pos.x, pos.y, pos.z);
  cam.lookAt(lookAt.x, lookAt.y, lookAt.z);
  cam.rotation.order = 'YXZ';
  cam.updateMatrixWorld(true);
  return cam;
}

console.log(`=== Catalogue: ${SPAWNERS.length} spawner tools ===`);
check('5 spawner kinds', SPAWNERS.length === 5, `got ${SPAWNERS.length}`);
check('all spawner ids unique', new Set(SPAWNERS.map((s) => s.id)).size === SPAWNERS.length);

console.log('\n=== Each spawner kind actually spawns the right thing, aimed like a gun ===');
SPAWNERS.forEach((spawner, i) => {
  const world = createPhysicsWorld();
  const scene = new THREE.Scene();
  const ground = new CANNON.Body({ mass: 0, material: defaultMaterial });
  ground.addShape(new CANNON.Plane());
  ground.quaternion.setFromEuler(-Math.PI / 2, 0, 0);
  ground.collisionFilterGroup = GROUP.DEFAULT;
  ground.collisionFilterMask = GROUP.DEFAULT | GROUP.RAGDOLL;
  world.addBody(ground);

  const camera = makeCamera({ x: 0, y: 1.5, z: 0 }, { x: 0, y: 1, z: -5 });
  const playerBody = new CANNON.Body({ mass: 70, position: new CANNON.Vec3(0, 0.95, 0) });
  const bodyCountBefore = world.bodies.length;
  const dummyCountBefore = allDummies().length;

  // Each spawner's cooldown state lives at module scope (correct for the
  // real game - there is only one of each tool). Tests must use time
  // values that can't collide with other blocks, so this uses a fixed,
  // deterministic offset per spawner instead of overlapping randoms.
  const result = trySpawn(spawner, { world, scene, camera, playerBody, time: 100 + i * 1000 });
  check(`${spawner.id}: spawn call did not throw and returned something`, !!result);

  if (spawner.kind === 'dummy') {
    check(`${spawner.id}: a new dummy was registered`, allDummies().length === dummyCountBefore + 1);
    const d = allDummies()[allDummies().length - 1];
    check(`${spawner.id}: dummy has no NaN position`, !Number.isNaN(d.ragdoll.parts.torso.position.x));
  } else {
    check(`${spawner.id}: a new physics body was added to the world`, world.bodies.length > bodyCountBefore);
    check(`${spawner.id}: spawned body has no NaN position`, !Number.isNaN(result.body.position.x));
    check(`${spawner.id}: spawned roughly in front of the camera (negative Z)`, result.body.position.z < -0.5, `z=${result.body.position.z.toFixed(2)}`);
  }
});

console.log('\n=== Cooldown prevents spamming a single spawner every frame ===');
{
  const world = createPhysicsWorld();
  const scene = new THREE.Scene();
  const camera = makeCamera({ x: 0, y: 1.5, z: 0 }, { x: 0, y: 1, z: -5 });
  const playerBody = new CANNON.Body({ mass: 70, position: new CANNON.Vec3(0, 0.95, 0) });
  const spawner = SPAWNERS.find((s) => s.kind === 'crate');
  const t0 = 50000; // far past anything used above or below, avoids any cross-block state collision
  const first = trySpawn(spawner, { world, scene, camera, playerBody, time: t0 });
  const second = trySpawn(spawner, { world, scene, camera, playerBody, time: t0 + 0.01 });
  const third = trySpawn(spawner, { world, scene, camera, playerBody, time: t0 + 2 });
  check('first spawn succeeds', !!first);
  check('immediate repeat is blocked by cooldown', second === null);
  check('spawn works again once cooldown has passed', !!third);
}

console.log('\n=== Regression: spawning while aiming down near the player never lands on top of them ===');
{
  // This is the actual bug: aiming mostly downward used to collapse the
  // fallback spawn point onto the player's own XZ position, and a physics
  // engine resolving that overlap is what produced the violent "teleport".
  const world = createPhysicsWorld();
  const scene = new THREE.Scene();
  const ground = new CANNON.Body({ mass: 0, material: defaultMaterial });
  ground.addShape(new CANNON.Plane());
  ground.quaternion.setFromEuler(-Math.PI / 2, 0, 0);
  ground.collisionFilterGroup = GROUP.DEFAULT;
  ground.collisionFilterMask = GROUP.DEFAULT | GROUP.RAGDOLL;
  world.addBody(ground);

  const camera = makeCamera({ x: 0, y: 0.95, z: 0 }, { x: 0, y: 0.1, z: -0.3 }); // looking almost straight down at own feet
  const playerBody = new CANNON.Body({ mass: 70, position: new CANNON.Vec3(0, 0.4, 0) });
  playerBody.addShape(new CANNON.Sphere(0.4));
  world.addBody(playerBody);

  SPAWNERS.forEach((spawner, i) => {
    const result = trySpawn(spawner, { world, scene, camera, playerBody, time: 100000 + i * 1000 });
    const p = spawner.kind === 'dummy' ? result.ragdoll.parts.torso.position : result.body.position;
    const flatDist = Math.hypot(p.x - playerBody.position.x, p.z - playerBody.position.z);
    check(`${spawner.id}: looking straight down still spawns clear of the player`, flatDist > 1.0, `flat distance=${flatDist.toFixed(2)}`);
  });
}

console.log('\n=== A hard cap prevents unbounded prop spam (evicts the oldest) ===');
{
  const world = createPhysicsWorld();
  const scene = new THREE.Scene();
  const camera = makeCamera({ x: 0, y: 1.5, z: 0 }, { x: 0, y: 1, z: -5 });
  const playerBody = new CANNON.Body({ mass: 70, position: new CANNON.Vec3(0, 0.95, 0) });
  const spawner = SPAWNERS.find((s) => s.kind === 'crate');
  const t0 = 200000;
  let first = null;
  for (let i = 0; i < 30; i++) {
    const r = trySpawn(spawner, { world, scene, camera, playerBody, time: t0 + i * 1 });
    if (i === 0) first = r;
  }
  check('spawned prop count never exceeds the cap even after 30 spawns', spawnedPropCount() <= 25, `count=${spawnedPropCount()}`);
  check('the oldest spawned crate was actually evicted from the world', !world.bodies.includes(first.body));
}

console.log(`\n${pass} passed, ${fail} failed`);
if (fail > 0) process.exit(1);
