#include <windows.h>
#include <shellapi.h>
#include <string.h>

int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow) {
    char path[MAX_PATH];
    DWORD len = GetModuleFileNameA(NULL, path, MAX_PATH);
    if (len == 0 || len >= MAX_PATH) {
        MessageBoxA(NULL, "Could not locate the game folder.", "Proving Grounds", MB_OK | MB_ICONERROR);
        return 1;
    }

    char *lastSlash = strrchr(path, '\\');
    if (lastSlash) {
        *(lastSlash + 1) = '\0';
    } else {
        path[0] = '\0';
    }
    strncat(path, "index.html", MAX_PATH - strlen(path) - 1);

    HINSTANCE result = ShellExecuteA(NULL, "open", path, NULL, NULL, SW_SHOWNORMAL);
    if ((INT_PTR)result <= 32) {
        MessageBoxA(NULL,
            "Could not open index.html in your default browser.\n"
            "Make sure index.html and bundle.js are in the same folder as this program, "
            "then try double clicking index.html directly.",
            "Proving Grounds", MB_OK | MB_ICONERROR);
        return 1;
    }
    return 0;
}
