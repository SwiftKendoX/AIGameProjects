import * as CANNON from 'cannon-es';

// Collision groups. Ragdoll parts never collide with other ragdoll-group
// bodies (including their own neighbouring limbs), which is what stops
// ragdolls from tearing themselves apart via internal self collision.
// Everything else collides with everything.
export const GROUP = {
  DEFAULT: 1,
  RAGDOLL: 2,
  PLAYER: 4,
};

export const defaultMaterial = new CANNON.Material('default');
export const playerMaterial = new CANNON.Material('player');
export const bouncyMaterial = new CANNON.Material('bouncy');

export function createPhysicsWorld() {
  const world = new CANNON.World({ gravity: new CANNON.Vec3(0, -9.82, 0) });
  world.broadphase = new CANNON.SAPBroadphase(world);
  world.allowSleep = true;
  world.defaultContactMaterial.friction = 0.45;
  world.defaultContactMaterial.restitution = 0.05;
  world.solver.iterations = 12;

  // The player drives its own horizontal velocity directly in player.js
  // every frame (for responsive FPS controls), which fights the physics
  // engine's own contact friction: the two end up in a tug of war that
  // settles at a fraction of the intended walk speed. Near-zero friction
  // here means the physics engine stops trying to also own that axis, so
  // the code that actually controls movement feel is the only thing that
  // does. This does not touch friction between anything else (crates,
  // barrels, ragdolls, sand still use the normal 0.45 default above).
  world.addContactMaterial(new CANNON.ContactMaterial(defaultMaterial, playerMaterial, { friction: 0.01, restitution: 0 }));
  world.addContactMaterial(new CANNON.ContactMaterial(playerMaterial, bouncyMaterial, { friction: 0.01, restitution: 0.2 }));
  // Restitution lives on a ContactMaterial pairing, not on a single
  // Material, so this is what actually makes the pipe bomb bounce.
  world.addContactMaterial(new CANNON.ContactMaterial(defaultMaterial, bouncyMaterial, { friction: 0.4, restitution: 0.7 }));

  return world;
}

export function stepWorld(world, dt) {
  // Fixed timestep with capped substeps so a slow frame never causes a
  // large, unstable physics jump.
  world.step(1 / 60, Math.min(dt, 0.1), 5);
}

export function makeMaterialPair(world, matA, matB, friction, restitution) {
  const cm = new CANNON.ContactMaterial(matA, matB, { friction, restitution });
  world.addContactMaterial(cm);
  return cm;
}

// Registry so gameplay code can go from a physics body straight to its
// visual mesh and any tags (ragdoll id, prop type, health) without a
// separate lookup table living in three or four different files.
export function tagBody(body, data) {
  body.userData = Object.assign(body.userData || {}, data);
  return body;
}

export function applyExplosionForce(world, position, radius, strength, { verticalBoost = 0.35 } = {}) {
  const affected = [];
  for (const body of world.bodies) {
    if (body.mass === 0) continue;
    const delta = new CANNON.Vec3().copy(body.position).vsub(position);
    const dist = delta.length();
    if (dist > radius || dist < 1e-4) continue;
    delta.normalize();
    const falloff = 1 - dist / radius;
    const magnitude = strength * falloff * falloff;
    const impulse = new CANNON.Vec3(delta.x * magnitude, delta.y * magnitude + magnitude * verticalBoost, delta.z * magnitude);
    body.applyImpulse(impulse, body.position);
    body.angularVelocity.set(
      body.angularVelocity.x + (Math.random() - 0.5) * falloff * 6,
      body.angularVelocity.y + (Math.random() - 0.5) * falloff * 6,
      body.angularVelocity.z + (Math.random() - 0.5) * falloff * 6
    );
    if (body.sleepState === CANNON.Body.SLEEPING) body.wakeUp();
    affected.push({ body, dist, falloff });
  }
  return affected;
}
