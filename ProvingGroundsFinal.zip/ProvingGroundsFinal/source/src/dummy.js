import * as THREE from 'three';
import * as CANNON from 'cannon-es';
import { createRagdoll, removeRagdoll, RAGDOLL_DIMS } from './ragdoll.js';
import { registerSynced, unregisterSynced } from './props.js';

export const MAX_HEALTH = 150;
const RECOVERY_DELAY = 3.2; // seconds after the last hit before it tries to stand back up
const RECOVERY_EASE_TIME = 1.6; // seconds to ramp the assist up to full strength, never instant
const TORQUE_KP = 110;
const TORQUE_KD = 16;
const MAX_TORQUE = 70;
const MAX_RECOVERY_ANGVEL = 1.3; // rad/s - hard cap regardless of what the torque math produces
const LIFT_KP = 650;
const MAX_LIFT_FORCE = 1000;
const MAX_RECOVERY_LINVEL = 1.5; // m/s - hard cap regardless of what the force math produces
const STAND_HEIGHTS = (() => {
  const d = RAGDOLL_DIMS;
  const lowerLegY = d.lowerLeg[1] / 2;
  const kneeY = d.lowerLeg[1];
  const upperLegY = kneeY + d.upperLeg[1] / 2;
  const hipY = kneeY + d.upperLeg[1];
  const pelvisY = hipY + d.pelvis[1] / 2;
  const torsoY = hipY + d.pelvis[1] + d.torso[1] / 2;
  const shoulderY = hipY + d.pelvis[1] + d.torso[1];
  const upperArmY = shoulderY - d.upperArm[1] / 2;
  const elbowY = shoulderY - d.upperArm[1];
  const lowerArmY = elbowY - d.lowerArm[1] / 2;
  const headY = shoulderY + d.head[1] / 2;
  return {
    pelvis: pelvisY,
    torso: torsoY,
    head: headY,
    upperLegL: upperLegY,
    upperLegR: upperLegY,
    lowerLegL: lowerLegY,
    lowerLegR: lowerLegY,
    upperArmL: upperArmY,
    upperArmR: upperArmY,
    lowerArmL: lowerArmY,
    lowerArmR: lowerArmY,
  };
})();
const STAND_PELVIS_Y = STAND_HEIGHTS.pelvis;

const registry = [];
const MAX_DUMMIES = 10;

const HAZARD = '#f2b400';
const HAZARD_DARK = '#c98f00';
const JOINT = '#17181a';

function partMesh(kind, size) {
  if (kind === 'head') {
    return new THREE.Mesh(new THREE.SphereGeometry(size[0] * 0.56, 16, 12), new THREE.MeshStandardMaterial({ color: HAZARD, roughness: 0.55, metalness: 0.05 }));
  }
  if (kind === 'torso' || kind === 'pelvis') {
    const mesh = new THREE.Mesh(new THREE.BoxGeometry(size[0], size[1], size[2]), new THREE.MeshStandardMaterial({ color: kind === 'pelvis' ? HAZARD_DARK : HAZARD, roughness: 0.6, metalness: 0.05 }));
    return mesh;
  }
  // limbs: capsules read as human silhouettes far better than boxes
  const radius = Math.max(size[0], size[2]) * 0.52;
  const length = Math.max(0.02, size[1] - radius * 2);
  return new THREE.Mesh(new THREE.CapsuleGeometry(radius, length, 4, 10), new THREE.MeshStandardMaterial({ color: HAZARD, roughness: 0.58, metalness: 0.05 }));
}

function jointDot(radius) {
  return new THREE.Mesh(new THREE.SphereGeometry(radius, 10, 8), new THREE.MeshStandardMaterial({ color: JOINT, roughness: 0.4, metalness: 0.3 }));
}

function buildDummyVisual(scene, ragdoll) {
  const d = RAGDOLL_DIMS;
  const sizeByPart = {
    head: d.head,
    torso: d.torso,
    pelvis: d.pelvis,
    upperArmL: d.upperArm,
    upperArmR: d.upperArm,
    lowerArmL: d.lowerArm,
    lowerArmR: d.lowerArm,
    upperLegL: d.upperLeg,
    upperLegR: d.upperLeg,
    lowerLegL: d.lowerLeg,
    lowerLegR: d.lowerLeg,
  };
  const meshes = {};
  for (const [name, body] of Object.entries(ragdoll.parts)) {
    const mesh = partMesh(name, sizeByPart[name]);
    mesh.castShadow = true;
    mesh.receiveShadow = true;
    scene.add(mesh);
    registerSynced(body, mesh);
    meshes[name] = mesh;
  }
  // Small dark joint markers at the shoulders, hips and neck give it the
  // simplified, high contrast look of a warning sign figure. They're built
  // as children of the already-synced limb meshes with a local offset to
  // the actual joint point, so they inherit correct position/rotation for
  // free instead of needing their own sync entry (which would place them
  // at the limb's center, not at the joint).
  const dotRadius = 0.055;
  function addJointDot(parentMesh, localY) {
    const dot = jointDot(dotRadius);
    dot.position.set(0, localY, 0);
    parentMesh.add(dot);
  }
  addJointDot(meshes.head, -sizeByPart.head[1] * 0.5); // neck, base of head
  addJointDot(meshes.upperArmL, d.upperArm[1] * 0.5); // shoulder
  addJointDot(meshes.upperArmR, d.upperArm[1] * 0.5);
  addJointDot(meshes.upperLegL, d.upperLeg[1] * 0.5); // hip
  addJointDot(meshes.upperLegR, d.upperLeg[1] * 0.5);

  return { meshes };
}

export function createDummy(world, scene, position) {
  if (registry.length >= MAX_DUMMIES) {
    removeDummy(world, scene, registry[0]);
  }
  const ragdoll = createRagdoll(world, new CANNON.Vec3(position.x, position.y, position.z));
  const visual = buildDummyVisual(scene, ragdoll);
  const dummy = {
    id: ragdoll.id,
    ragdoll,
    visual,
    health: MAX_HEALTH,
    lastHitTime: -999,
    get dead() {
      return this.health <= 0;
    },
  };
  registry.push(dummy);
  return dummy;
}

export function findDummyByBody(body) {
  const ragdollId = body.userData && body.userData.ragdollId;
  if (ragdollId === undefined) return null;
  return registry.find((d) => d.id === ragdollId) || null;
}

export function damageDummy(dummy, amount, time) {
  if (dummy.dead) return;
  dummy.health = Math.max(0, dummy.health - amount);
  dummy.lastHitTime = time;
}

export function removeDummy(world, scene, dummy) {
  removeRagdoll(world, dummy.ragdoll);
  for (const body of dummy.ragdoll.bodies) unregisterSynced(body);
  for (const mesh of Object.values(dummy.visual.meshes)) scene.remove(mesh);
  const i = registry.indexOf(dummy);
  if (i !== -1) registry.splice(i, 1);
}

export function allDummies() {
  return registry;
}

// Applies a standing/recovery assist unless the dummy was hit recently or
// is dead. This is what makes "ragdolls completely, then stands back up on
// its own" work: the moment something hits it, lastHitTime resets and this
// function returns immediately, so normal, fully unassisted ragdoll physics
// takes over (already tested separately in ragdoll.test.js). Only once
// enough time has passed does this ease it back upright, using forces on
// the torso/pelvis only and letting the limbs follow through their existing
// joints, rather than snapping to a pose.
export function updateDummy(dummy, time) {
  if (dummy.dead) return;
  if (time - dummy.lastHitTime < RECOVERY_DELAY) return;

  const { torso, pelvis } = dummy.ragdoll.parts;

  // Hard safety net, applied to every single part, unconditionally,
  // before anything below decides whether to add new force. This must
  // never be skippable: the deadzone check further down can legitimately
  // decide "no new force needed", but that must never also mean "skip the
  // speed cap", or residual velocity from a moment ago (or transmitted
  // through a joint from a part this function never even touches
  // directly) goes uncapped. That gap is exactly what let a dummy spike
  // to 56 rad/s the first time this deadzone was added - the clamp lived
  // at the end of the function, so the early "already standing" return
  // skipped straight past it.
  for (const body of dummy.ragdoll.bodies) {
    clampVec3(body.velocity, MAX_RECOVERY_LINVEL);
    clampVec3(body.angularVelocity, MAX_RECOVERY_ANGVEL);
  }

  // If it's already close enough to standing, apply no new force at all.
  // Without this, the assist keeps running forever, including on a dummy
  // that is already standing correctly with zero error, which makes it
  // feel glued in place: bump into a "standing" dummy and the assist just
  // fights back to the exact same spot instead of letting it react like a
  // normal physics object. Once it's actually upright, it becomes a
  // completely free ragdoll again (still speed-capped above, just with no
  // active force), and only reactivates if something genuinely knocks it
  // down again (a real height/orientation error to correct).
  const localUp = new CANNON.Vec3(0, 1, 0);
  const worldUp = new CANNON.Vec3();
  torso.quaternion.vmult(localUp, worldUp);
  const trueUp = new CANNON.Vec3(0, 1, 0);
  const axis = new CANNON.Vec3();
  worldUp.cross(trueUp, axis);
  const uprightError = Math.min(1, axis.length());
  const heightErrorNow = STAND_PELVIS_Y - pelvis.position.y;
  if (uprightError < 0.06 && heightErrorNow < 0.12) return;

  // Ease the assist in from zero over RECOVERY_EASE_TIME rather than
  // switching from "no force" to "full force" on a single frame, which is
  // what made this violent before.
  const ease = Math.min(1, (time - dummy.lastHitTime - RECOVERY_DELAY) / RECOVERY_EASE_TIME);

  // Torque toward upright, reusing the up-vector error already computed
  // above.
  const errorMag = uprightError;
  if (axis.length() > 1e-5) axis.normalize();

  let tx = (axis.x * errorMag * TORQUE_KP - torso.angularVelocity.x * TORQUE_KD) * ease;
  let ty = (axis.y * errorMag * TORQUE_KP - torso.angularVelocity.y * TORQUE_KD) * ease;
  let tz = (axis.z * errorMag * TORQUE_KP - torso.angularVelocity.z * TORQUE_KD) * ease;
  const tmag = Math.hypot(tx, ty, tz);
  if (tmag > MAX_TORQUE) {
    const s = MAX_TORQUE / tmag;
    tx *= s;
    ty *= s;
    tz *= s;
  }
  torso.torque.x += tx;
  torso.torque.y += ty;
  torso.torque.z += tz;
  torso.wakeUp();

  // Lift toward standing height via the pelvis and torso.
  const heightError = heightErrorNow;
  if (heightError > 0.02) {
    const lift = Math.min(MAX_LIFT_FORCE, heightError * LIFT_KP) * ease;
    pelvis.force.y += lift;
    torso.force.y += lift * 0.5;
    pelvis.wakeUp();
  }
  pelvis.force.x += (torso.position.x - pelvis.position.x) * 6 * ease;
  pelvis.force.z += (torso.position.z - pelvis.position.z) * 6 * ease;

  // Every other limb also gets a gentle pull toward its own standing
  // height, not just the pelvis and torso. Without this, legs left
  // splayed flat on the ground after a fall act as a dead anchor: lifting
  // only the pelvis just rotates around them instead of actually rising,
  // and the whole recovery stalls partway. This is deliberately gentler
  // per part (using each part's own mass, and a lower ceiling) since it's
  // meant to un-stick things, not do the main work of standing up.
  for (const [name, body] of Object.entries(dummy.ragdoll.parts)) {
    if (name === 'pelvis' || name === 'torso') continue;
    const target = STAND_HEIGHTS[name];
    const err = target - body.position.y;
    if (err > 0.02) {
      const lift = Math.min(MAX_LIFT_FORCE * 0.35, err * LIFT_KP * 0.5 * body.mass) * ease;
      body.force.y += lift;
      body.wakeUp();
    }
  }
}

function clampVec3(v, max) {
  const mag = Math.hypot(v.x, v.y, v.z);
  if (mag > max) {
    const s = max / mag;
    v.x *= s;
    v.y *= s;
    v.z *= s;
  }
}
