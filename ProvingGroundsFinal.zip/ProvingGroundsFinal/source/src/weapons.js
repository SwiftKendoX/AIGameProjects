import * as THREE from 'three';
import * as CANNON from 'cannon-es';
import { GROUP, applyExplosionForce, defaultMaterial, bouncyMaterial } from './physics.js';
import { spawnImpactBurst, spawnMuzzleFlash, spawnExplosion } from './effects.js';
import { allSynced, removeProp } from './props.js';
import { findDummyByBody, damageDummy } from './dummy.js';
import { metalTexture, woodTexture } from './textures.js';

let metalTex, woodTex;
function tex() {
  if (!metalTex) {
    metalTex = metalTexture(3, '#8b9096');
    woodTex = woodTexture(1);
  }
  return { metalTex, woodTex };
}

// ---------- viewmodel mesh builders (low poly, primitive based) ----------

function darkMetal(color = '#3a3c3f', rough = 0.45, metal = 0.75) {
  const { metalTex } = tex();
  return new THREE.MeshStandardMaterial({ map: metalTex, color, roughness: rough, metalness: metal });
}

function buildGunMesh({ color = '#33353a', bodyLen = 0.42, barrelLen = 0.28, hasStock = false, hasScope = false, hasDrum = false, wide = 0.075 }) {
  const g = new THREE.Group();
  const mat = darkMetal(color);

  const body = new THREE.Mesh(new THREE.BoxGeometry(wide, wide * 1.15, bodyLen), mat);
  body.position.z = -bodyLen * 0.3;
  g.add(body);

  const grip = new THREE.Mesh(new THREE.BoxGeometry(wide * 0.8, 0.22, wide * 1.1), darkMetal('#20211f', 0.8, 0.1));
  grip.position.set(0, -0.15, -bodyLen * 0.05);
  grip.rotation.x = 0.25;
  g.add(grip);

  const barrel = new THREE.Mesh(new THREE.CylinderGeometry(wide * 0.28, wide * 0.32, barrelLen, 10), darkMetal('#1c1d1f', 0.35, 0.85));
  barrel.rotation.x = Math.PI / 2;
  barrel.position.z = -bodyLen * 0.6 - barrelLen / 2;
  g.add(barrel);
  g.userData.muzzleLocalPos = new THREE.Vector3(0, 0, -bodyLen * 0.6 - barrelLen);

  const trigger = new THREE.Mesh(new THREE.BoxGeometry(0.02, 0.06, 0.02), darkMetal('#15161a', 0.5, 0.5));
  trigger.position.set(0, -0.04, -bodyLen * 0.02);
  g.add(trigger);

  if (hasStock) {
    const stock = new THREE.Mesh(new THREE.BoxGeometry(wide * 0.7, wide * 0.9, 0.32), darkMetal('#2a1c12', 0.75, 0.15));
    stock.position.z = bodyLen * 0.35;
    g.add(stock);
  }
  if (hasScope) {
    const scope = new THREE.Mesh(new THREE.CylinderGeometry(0.03, 0.03, 0.22, 10), darkMetal('#0e0f10', 0.3, 0.7));
    scope.rotation.x = Math.PI / 2;
    scope.position.set(0, wide * 0.8, -bodyLen * 0.25);
    g.add(scope);
  }
  if (hasDrum) {
    const drum = new THREE.Mesh(new THREE.CylinderGeometry(0.09, 0.09, 0.06, 14), darkMetal('#26282b'));
    drum.position.set(0, -0.08, -bodyLen * 0.1);
    g.add(drum);
  }
  return g;
}

function buildMeleeMesh({ kind }) {
  const g = new THREE.Group();
  const { woodTex } = tex();
  const handleMat = new THREE.MeshStandardMaterial({ map: woodTex, roughness: 0.85 });
  const metalMat = darkMetal('#7b7e82', 0.4, 0.8);

  if (kind === 'bat') {
    const handle = new THREE.Mesh(new THREE.CylinderGeometry(0.02, 0.028, 0.35, 10), handleMat);
    const head = new THREE.Mesh(new THREE.CylinderGeometry(0.05, 0.032, 0.45, 10), handleMat);
    head.position.z = -0.42;
    g.add(handle, head);
    g.userData.tipLocalPos = new THREE.Vector3(0, 0, -0.65);
  } else if (kind === 'crowbar') {
    const shaft = new THREE.Mesh(new THREE.BoxGeometry(0.03, 0.03, 0.55), metalMat);
    const hook = new THREE.Mesh(new THREE.BoxGeometry(0.03, 0.14, 0.05), metalMat);
    hook.position.set(0, 0.06, -0.28);
    hook.rotation.x = 0.6;
    g.add(shaft, hook);
    g.userData.tipLocalPos = new THREE.Vector3(0, 0.1, -0.5);
  } else if (kind === 'machete') {
    const handle = new THREE.Mesh(new THREE.CylinderGeometry(0.022, 0.022, 0.16, 8), handleMat);
    const blade = new THREE.Mesh(new THREE.BoxGeometry(0.09, 0.012, 0.55), darkMetal('#c7cbcf', 0.25, 0.9));
    blade.position.z = -0.34;
    g.add(handle, blade);
    g.userData.tipLocalPos = new THREE.Vector3(0, 0, -0.6);
  } else if (kind === 'sledgehammer') {
    const handle = new THREE.Mesh(new THREE.CylinderGeometry(0.025, 0.03, 0.62, 10), handleMat);
    const head = new THREE.Mesh(new THREE.BoxGeometry(0.16, 0.13, 0.22), darkMetal('#4a4c4f', 0.55, 0.6));
    head.position.z = -0.42;
    g.add(handle, head);
    g.userData.tipLocalPos = new THREE.Vector3(0, 0, -0.55);
  } else {
    // knife
    const handle = new THREE.Mesh(new THREE.CylinderGeometry(0.018, 0.018, 0.12, 8), new THREE.MeshStandardMaterial({ color: '#1c1d1f', roughness: 0.6 }));
    const blade = new THREE.Mesh(new THREE.BoxGeometry(0.045, 0.008, 0.2), darkMetal('#d8dbde', 0.2, 0.9));
    blade.position.z = -0.16;
    g.add(handle, blade);
    g.userData.tipLocalPos = new THREE.Vector3(0, 0, -0.28);
  }
  return g;
}

function buildExplosiveMesh({ kind }) {
  const g = new THREE.Group();
  if (kind === 'grenade') {
    const body = new THREE.Mesh(new THREE.SphereGeometry(0.075, 12, 10), darkMetal('#4a5a3c', 0.6, 0.4));
    const pin = new THREE.Mesh(new THREE.TorusGeometry(0.02, 0.006, 6, 10), darkMetal('#c7cbcf', 0.3, 0.8));
    pin.position.set(0.06, 0.05, 0);
    g.add(body, pin);
  } else if (kind === 'dynamite') {
    for (let i = -1; i <= 1; i++) {
      const stick = new THREE.Mesh(new THREE.CylinderGeometry(0.028, 0.028, 0.22, 10), new THREE.MeshStandardMaterial({ color: '#a3372f', roughness: 0.7 }));
      stick.position.x = i * 0.06;
      g.add(stick);
    }
  } else if (kind === 'c4') {
    const block = new THREE.Mesh(new THREE.BoxGeometry(0.14, 0.04, 0.09), new THREE.MeshStandardMaterial({ color: '#c7c2a8', roughness: 0.6 }));
    const light = new THREE.Mesh(new THREE.BoxGeometry(0.02, 0.01, 0.02), new THREE.MeshBasicMaterial({ color: '#ff3b30' }));
    light.position.set(0, 0.025, 0.03);
    g.add(block, light);
    g.userData.blinker = light;
  } else if (kind === 'pipebomb') {
    const pipe = new THREE.Mesh(new THREE.CylinderGeometry(0.035, 0.035, 0.2, 10), darkMetal('#5c5f63'));
    const capA = new THREE.Mesh(new THREE.CylinderGeometry(0.038, 0.038, 0.015, 10), darkMetal('#2a2b2d'));
    capA.position.y = 0.1;
    const capB = capA.clone();
    capB.position.y = -0.1;
    g.add(pipe, capA, capB);
  } else {
    // sticky bomb
    const body = new THREE.Mesh(new THREE.BoxGeometry(0.1, 0.05, 0.1), new THREE.MeshStandardMaterial({ color: '#2c2e31', roughness: 0.5 }));
    const light = new THREE.Mesh(new THREE.SphereGeometry(0.012, 6, 6), new THREE.MeshBasicMaterial({ color: '#3bd6ff' }));
    light.position.y = 0.03;
    g.add(body, light);
    g.userData.blinker = light;
  }
  return g;
}

// ---------- weapon catalogue ----------
// Every gun shares fireGun(), every melee shares swingMelee(), every
// explosive shares throwExplosive(). Only the numbers and the mesh differ,
// which is what keeps 15 weapons testable through three code paths instead
// of fifteen.

export const WEAPONS = [
  { id: 'pistol', name: 'Pistol', category: 'gun', damage: 18, fireRate: 0.28, auto: false, spread: 0.01, impulse: 6, magSize: 12, reloadTime: 1.1, mesh: () => buildGunMesh({ color: '#33353a', bodyLen: 0.3, barrelLen: 0.16, wide: 0.06 }) },
  { id: 'smg', name: 'SMG', category: 'gun', damage: 10, fireRate: 0.09, auto: true, spread: 0.045, impulse: 4, magSize: 30, reloadTime: 1.6, mesh: () => buildGunMesh({ color: '#2c2e31', bodyLen: 0.36, barrelLen: 0.2, hasDrum: true, wide: 0.065 }) },
  { id: 'shotgun', name: 'Shotgun', category: 'gun', damage: 9, pellets: 8, fireRate: 0.75, auto: false, spread: 0.1, impulse: 5, magSize: 6, reloadTime: 2.2, mesh: () => buildGunMesh({ color: '#3a2c1c', bodyLen: 0.5, barrelLen: 0.4, hasStock: true, wide: 0.08 }) },
  { id: 'rifle', name: 'Rifle', category: 'gun', damage: 30, fireRate: 0.14, auto: true, spread: 0.02, impulse: 9, magSize: 25, reloadTime: 1.8, mesh: () => buildGunMesh({ color: '#22261f', bodyLen: 0.52, barrelLen: 0.36, hasStock: true, wide: 0.072 }) },
  { id: 'sniper', name: 'Sniper', category: 'gun', damage: 95, fireRate: 1.1, auto: false, spread: 0.0015, impulse: 16, magSize: 5, reloadTime: 2.6, scope: true, mesh: () => buildGunMesh({ color: '#26282b', bodyLen: 0.62, barrelLen: 0.5, hasStock: true, hasScope: true, wide: 0.07 }) },

  { id: 'bat', name: 'Baseball Bat', category: 'melee', damage: 35, range: 1.6, swingTime: 0.4, impulse: 10, mesh: () => buildMeleeMesh({ kind: 'bat' }) },
  { id: 'crowbar', name: 'Crowbar', category: 'melee', damage: 30, range: 1.5, swingTime: 0.35, impulse: 9, mesh: () => buildMeleeMesh({ kind: 'crowbar' }) },
  { id: 'machete', name: 'Machete', category: 'melee', damage: 40, range: 1.5, swingTime: 0.3, impulse: 8, mesh: () => buildMeleeMesh({ kind: 'machete' }) },
  { id: 'sledgehammer', name: 'Sledgehammer', category: 'melee', damage: 55, range: 1.7, swingTime: 0.6, impulse: 17, mesh: () => buildMeleeMesh({ kind: 'sledgehammer' }) },
  { id: 'knife', name: 'Knife', category: 'melee', damage: 22, range: 1.2, swingTime: 0.2, impulse: 5, mesh: () => buildMeleeMesh({ kind: 'knife' }) },

  { id: 'grenade', name: 'Grenade', category: 'explosive', fuse: 2.5, radius: 5, force: 13, throwSpeed: 11, mesh: () => buildExplosiveMesh({ kind: 'grenade' }) },
  { id: 'dynamite', name: 'Dynamite', category: 'explosive', fuse: 3.5, radius: 6.5, force: 16, throwSpeed: 8, mesh: () => buildExplosiveMesh({ kind: 'dynamite' }) },
  { id: 'c4', name: 'Remote C4', category: 'explosive', sticky: true, remote: true, radius: 7, force: 18, throwSpeed: 9, mesh: () => buildExplosiveMesh({ kind: 'c4' }) },
  { id: 'pipebomb', name: 'Pipe Bomb', category: 'explosive', fuse: 2, radius: 5.5, force: 15, throwSpeed: 12, bouncy: true, mesh: () => buildExplosiveMesh({ kind: 'pipebomb' }) },
  { id: 'stickybomb', name: 'Sticky Bomb', category: 'explosive', sticky: true, fuse: 1.8, radius: 4.5, force: 12, throwSpeed: 13, mesh: () => buildExplosiveMesh({ kind: 'stickybomb' }) },
];

// ---------- shared runtime state ----------

export function createWeaponRuntime() {
  const state = {};
  for (const w of WEAPONS) {
    if (w.category === 'gun') state[w.id] = { ammo: w.magSize, reloading: false, lastFire: -999 };
    else if (w.category === 'melee') state[w.id] = { swinging: false, lastSwing: -999 };
    else state[w.id] = { lastThrow: -999 };
  }
  return state;
}

function findPropEntry(body) {
  return allSynced().find((s) => s.body === body);
}

function damageBody(body, amount, ctx) {
  const ud = body.userData;
  if (!ud) return;
  if (ud.type === 'prop' && typeof ud.health === 'number') {
    ud.health -= amount;
    if (ud.health <= 0 && !ud._dying) {
      ud._dying = true;
      const entry = findPropEntry(body);
      if (entry) {
        if (ud.explosive) {
          applyExplosionForce(ctx.world, body.position, 4.5, 11);
          spawnExplosion(new THREE.Vector3(body.position.x, body.position.y, body.position.z), 4.5);
        }
        removeProp(ctx.world, ctx.scene, entry);
      }
    }
  } else if (ud.type === 'ragdoll') {
    const dummy = findDummyByBody(body);
    if (dummy) damageDummy(dummy, amount, ctx.time);
  }
}

// ---------- GUNS: single shared hitscan implementation ----------

export function fireGun(weapon, ctx) {
  const s = ctx.state[weapon.id];
  const now = ctx.time;
  if (s.reloading) return false;
  if (now - s.lastFire < weapon.fireRate) return false;
  if (s.ammo <= 0) {
    startReload(weapon, ctx);
    return false;
  }
  s.lastFire = now;
  s.ammo--;
  let hitConfirmed = false;

  const shots = weapon.pellets || 1;
  const origin = ctx.camera.getWorldPosition(new THREE.Vector3());
  const forward = ctx.camera.getWorldDirection(new THREE.Vector3());

  for (let i = 0; i < shots; i++) {
    const dir = forward.clone();
    dir.x += (Math.random() - 0.5) * weapon.spread;
    dir.y += (Math.random() - 0.5) * weapon.spread;
    dir.z += (Math.random() - 0.5) * weapon.spread;
    dir.normalize();

    const from = new CANNON.Vec3(origin.x, origin.y, origin.z);
    const to = new CANNON.Vec3(origin.x + dir.x * 200, origin.y + dir.y * 200, origin.z + dir.z * 200);
    const result = new CANNON.RaycastResult();
    ctx.world.raycastClosest(from, to, { collisionFilterMask: GROUP.DEFAULT | GROUP.RAGDOLL }, result);
    if (result.hasHit) {
      const hitPoint = new THREE.Vector3(result.hitPointWorld.x, result.hitPointWorld.y, result.hitPointWorld.z);
      const normal = new THREE.Vector3(result.hitNormalWorld.x, result.hitNormalWorld.y, result.hitNormalWorld.z);
      const impulse = new CANNON.Vec3(dir.x * weapon.impulse, dir.y * weapon.impulse, dir.z * weapon.impulse);
      result.body.applyImpulse(impulse, result.hitPointWorld);
      if (result.body.sleepState === CANNON.Body.SLEEPING) result.body.wakeUp();
      const organic = result.body.userData && result.body.userData.type === 'ragdoll';
      spawnImpactBurst(hitPoint, normal, organic ? 'organic' : 'spark');
      damageBody(result.body, weapon.damage, ctx);
      hitConfirmed = true;
    }
  }

  const muzzleWorld = ctx.viewmodel.getMuzzleWorldPosition();
  spawnMuzzleFlash(muzzleWorld, forward);
  ctx.viewmodel.triggerRecoil();
  if (s.ammo <= 0) startReload(weapon, ctx);
  return { fired: true, hit: hitConfirmed };
}

export function startReload(weapon, ctx) {
  const s = ctx.state[weapon.id];
  if (s.reloading || s.ammo === weapon.magSize) return;
  s.reloading = true;
  s.reloadEndsAt = ctx.time + weapon.reloadTime;
  ctx.viewmodel.triggerReload(weapon.reloadTime);
}

export function updateGun(weapon, ctx) {
  const s = ctx.state[weapon.id];
  if (s.reloading && ctx.time >= s.reloadEndsAt) {
    s.reloading = false;
    s.ammo = weapon.magSize;
  }
}

// ---------- MELEE: single shared swing implementation ----------

export function swingMelee(weapon, ctx) {
  const s = ctx.state[weapon.id];
  if (now2(s, ctx) < weapon.swingTime) return false;
  s.lastSwing = ctx.time;
  ctx.viewmodel.triggerSwing(weapon.swingTime);

  const origin = ctx.camera.getWorldPosition(new THREE.Vector3());
  const forward = ctx.camera.getWorldDirection(new THREE.Vector3());
  const checkPoint = origin.clone().addScaledVector(forward, weapon.range * 0.65);

  let hitSomething = false;
  for (const body of ctx.world.bodies) {
    if (body.mass === 0) continue;
    if (body === ctx.playerBody) continue;
    const bp = new THREE.Vector3(body.position.x, body.position.y, body.position.z);
    if (bp.distanceTo(checkPoint) < 0.55 && bp.distanceTo(origin) < weapon.range + 0.5) {
      const impulse = new CANNON.Vec3(forward.x * weapon.impulse, forward.y * weapon.impulse + weapon.impulse * 0.2, forward.z * weapon.impulse);
      body.applyImpulse(impulse, body.position);
      if (body.sleepState === CANNON.Body.SLEEPING) body.wakeUp();
      const organic = body.userData && body.userData.type === 'ragdoll';
      spawnImpactBurst(bp, forward, organic ? 'organic' : 'material');
      damageBody(body, weapon.damage, ctx);
      hitSomething = true;
    }
  }
  return hitSomething;
}

function now2(s, ctx) {
  return ctx.time - s.lastSwing;
}

// ---------- EXPLOSIVES: single shared throw implementation ----------

const liveExplosives = [];

export function throwExplosive(weapon, ctx) {
  const s = ctx.state[weapon.id];
  if (weapon.remote) {
    // C4 has no fuse: throwing places it, detonate is triggered separately.
  } else if (ctx.time - s.lastThrow < 0.5) {
    return false;
  }
  s.lastThrow = ctx.time;

  const origin = ctx.camera.getWorldPosition(new THREE.Vector3());
  const forward = ctx.camera.getWorldDirection(new THREE.Vector3());
  const spawnPos = origin.clone().addScaledVector(forward, 0.6);

  const body = new CANNON.Body({
    mass: 1.2,
    position: new CANNON.Vec3(spawnPos.x, spawnPos.y, spawnPos.z),
    linearDamping: 0.15,
    angularDamping: 0.3,
    material: weapon.bouncy ? bouncyMaterial : defaultMaterial,
  });
  body.addShape(new CANNON.Sphere(0.08));
  body.collisionFilterGroup = GROUP.DEFAULT;
  body.collisionFilterMask = GROUP.DEFAULT | GROUP.RAGDOLL;
  body.userData = { type: 'explosive', weaponId: weapon.id };
  body.velocity.set(forward.x * weapon.throwSpeed, forward.y * weapon.throwSpeed + 2.5, forward.z * weapon.throwSpeed);
  body.angularVelocity.set((Math.random() - 0.5) * 8, (Math.random() - 0.5) * 8, (Math.random() - 0.5) * 8);
  ctx.world.addBody(body);

  const mesh = weapon.mesh();
  ctx.scene.add(mesh);
  mesh.castShadow = true;

  const entry = {
    body,
    mesh,
    weapon,
    stuck: false,
    detonateAt: weapon.remote ? Infinity : ctx.time + weapon.fuse,
    blinker: mesh.userData.blinker,
  };
  liveExplosives.push(entry);

  if (weapon.sticky || weapon.remote) {
    body.addEventListener('collide', (e) => {
      if (entry.stuck) return;
      const other = e.body;
      if (other.mass > 0) {
        const c = new CANNON.LockConstraint(body, other, { maxForce: 1e7 });
        ctx.world.addConstraint(c);
        entry.lockConstraint = c;
      } else {
        body.velocity.set(0, 0, 0);
        body.angularVelocity.set(0, 0, 0);
        body.linearDamping = 0.99;
        body.angularDamping = 0.99;
      }
      entry.stuck = true;
    });
  }

  return entry;
}

export function detonateAllRemote(weaponId, ctx) {
  for (const e of liveExplosives) {
    if (e.weapon.id === weaponId && e.weapon.remote) e.detonateAt = ctx.time;
  }
}

export function updateExplosives(ctx) {
  for (let i = liveExplosives.length - 1; i >= 0; i--) {
    const e = liveExplosives[i];
    e.mesh.position.set(e.body.position.x, e.body.position.y, e.body.position.z);
    e.mesh.quaternion.set(e.body.quaternion.x, e.body.quaternion.y, e.body.quaternion.z, e.body.quaternion.w);
    if (e.blinker) {
      const on = Math.floor(ctx.time * 4) % 2 === 0;
      e.blinker.material.color.set(on ? '#ff3b30' : '#3a0e0b');
    }
    if (ctx.time >= e.detonateAt) {
      const pos = new THREE.Vector3(e.body.position.x, e.body.position.y, e.body.position.z);
      applyExplosionForce(ctx.world, e.body.position, e.weapon.radius, e.weapon.force);
      spawnExplosion(pos, e.weapon.radius);
      for (const s of allSynced()) {
        if (s.body.userData && s.body.userData.type === 'prop' && typeof s.body.userData.health === 'number') {
          const d = new THREE.Vector3(s.body.position.x, s.body.position.y, s.body.position.z).distanceTo(pos);
          if (d < e.weapon.radius) damageBody(s.body, 60, ctx);
        }
      }
      if (e.lockConstraint) ctx.world.removeConstraint(e.lockConstraint);
      ctx.world.removeBody(e.body);
      ctx.scene.remove(e.mesh);
      liveExplosives.splice(i, 1);
    }
  }
}

export function activeExplosiveCount() {
  return liveExplosives.length;
}
