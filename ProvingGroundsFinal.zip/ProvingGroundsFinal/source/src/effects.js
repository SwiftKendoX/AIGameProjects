import * as THREE from 'three';

const MAX_PARTICLES = 260;
let particles = [];
let lights = [];
let scene = null;

export function initEffects(threeScene) {
  scene = threeScene;
}

const burstGeo = new THREE.BoxGeometry(0.045, 0.045, 0.045);
const sparkGeo = new THREE.BoxGeometry(0.03, 0.03, 0.03);

function trim() {
  while (particles.length > MAX_PARTICLES) {
    const p = particles.shift();
    scene.remove(p.mesh);
  }
}

export function spawnImpactBurst(position, normal, kind = 'material') {
  const color = kind === 'organic' ? '#a83232' : kind === 'spark' ? '#ffd27a' : '#5a5d61';
  const count = kind === 'organic' ? 10 : 7;
  const mat = new THREE.MeshBasicMaterial({ color });
  for (let i = 0; i < count; i++) {
    const mesh = new THREE.Mesh(kind === 'spark' ? sparkGeo : burstGeo, mat);
    mesh.position.copy(position);
    scene.add(mesh);
    const dir = new THREE.Vector3(
      normal.x + (Math.random() - 0.5) * 1.4,
      normal.y + Math.random() * 1.2,
      normal.z + (Math.random() - 0.5) * 1.4
    ).normalize();
    const speed = 1.5 + Math.random() * 2.5;
    particles.push({
      mesh,
      velocity: dir.multiplyScalar(speed),
      life: 0.5 + Math.random() * 0.4,
      age: 0,
      gravity: kind === 'organic' ? 3.5 : 4.5,
    });
  }
  trim();
}

export function spawnMuzzleFlash(position, direction) {
  const light = new THREE.PointLight('#ffcf6b', 6, 4, 2);
  light.position.copy(position);
  scene.add(light);
  lights.push({ light, life: 0.06, age: 0 });

  const geo = new THREE.ConeGeometry(0.06, 0.16, 6);
  const mesh = new THREE.Mesh(geo, new THREE.MeshBasicMaterial({ color: '#ffe9b0' }));
  mesh.position.copy(position);
  mesh.lookAt(position.clone().add(direction));
  mesh.rotateX(Math.PI / 2);
  scene.add(mesh);
  particles.push({ mesh, velocity: new THREE.Vector3(), life: 0.05, age: 0, gravity: 0, noFall: true });
}

export function spawnExplosion(position, radius) {
  const light = new THREE.PointLight('#ffb454', 18, radius * 4, 2);
  light.position.copy(position);
  scene.add(light);
  lights.push({ light, life: 0.35, age: 0, maxIntensity: 18 });

  const flashGeo = new THREE.SphereGeometry(0.3, 12, 8);
  const flashMat = new THREE.MeshBasicMaterial({ color: '#ffbb55', transparent: true, opacity: 0.9 });
  const flash = new THREE.Mesh(flashGeo, flashMat);
  flash.position.copy(position);
  scene.add(flash);
  particles.push({ mesh: flash, velocity: new THREE.Vector3(), life: 0.3, age: 0, gravity: 0, growTo: radius * 0.9, isFlash: true });

  const smokeMat = new THREE.MeshBasicMaterial({ color: '#3a3a3a' });
  for (let i = 0; i < 16; i++) {
    const mesh = new THREE.Mesh(burstGeo, smokeMat);
    mesh.position.copy(position);
    mesh.scale.setScalar(2 + Math.random() * 3);
    scene.add(mesh);
    const dir = new THREE.Vector3((Math.random() - 0.5) * 2, Math.random() * 1.6, (Math.random() - 0.5) * 2).normalize();
    particles.push({
      mesh,
      velocity: dir.multiplyScalar(2 + Math.random() * 3),
      life: 1.2 + Math.random() * 0.8,
      age: 0,
      gravity: -0.4,
      spin: (Math.random() - 0.5) * 4,
    });
  }
  trim();
}

export function updateEffects(dt) {
  for (let i = particles.length - 1; i >= 0; i--) {
    const p = particles[i];
    p.age += dt;
    if (p.age >= p.life) {
      scene.remove(p.mesh);
      particles.splice(i, 1);
      continue;
    }
    const t = p.age / p.life;
    if (!p.noFall) {
      p.velocity.y -= (p.gravity || 5) * dt;
      p.mesh.position.addScaledVector(p.velocity, dt);
    }
    if (p.spin) p.mesh.rotation.x += p.spin * dt;
    if (p.isFlash) {
      const s = 0.3 + p.growTo * t;
      p.mesh.scale.setScalar(s);
      p.mesh.material.opacity = 0.9 * (1 - t);
    } else {
      p.mesh.scale.setScalar(Math.max(0.05, 1 - t * 0.6));
    }
  }
  for (let i = lights.length - 1; i >= 0; i--) {
    const l = lights[i];
    l.age += dt;
    if (l.age >= l.life) {
      scene.remove(l.light);
      lights.splice(i, 1);
      continue;
    }
    l.light.intensity = (l.maxIntensity || 6) * (1 - l.age / l.life);
  }
}
