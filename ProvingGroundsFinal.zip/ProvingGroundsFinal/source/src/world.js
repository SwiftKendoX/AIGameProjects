import * as THREE from 'three';
import * as CANNON from 'cannon-es';
import { GROUP, defaultMaterial } from './physics.js';
import { concreteTexture, hazardStripeTexture, metalTexture, sandTexture, makeLabelSprite } from './textures.js';
import { spawnCrate, spawnBarrel, spawnPlank, spawnTarget, spawnSandParticle, registerSynced, allSynced } from './props.js';
import { createDummy } from './dummy.js';

const WORLD_SIZE = 130;

function staticBody(world, scene, mesh, shape, position, quaternion) {
  const body = new CANNON.Body({ mass: 0, material: defaultMaterial });
  body.addShape(shape);
  body.position.set(position.x, position.y, position.z);
  if (quaternion) body.quaternion.copy(quaternion);
  body.collisionFilterGroup = GROUP.DEFAULT;
  body.collisionFilterMask = GROUP.DEFAULT | GROUP.RAGDOLL | GROUP.PLAYER;
  world.addBody(body);
  mesh.position.copy(body.position);
  if (quaternion) mesh.quaternion.copy(quaternion);
  mesh.receiveShadow = true;
  mesh.castShadow = true;
  scene.add(mesh);
  return body;
}

function label(scene, text, position) {
  const sprite = makeLabelSprite(text);
  sprite.position.set(position.x, position.y, position.z);
  scene.add(sprite);
  return sprite;
}

function box(world, scene, size, position, opts = {}) {
  const mat = opts.material || new THREE.MeshStandardMaterial({ color: opts.color || '#888', roughness: opts.roughness ?? 0.8, metalness: opts.metalness ?? 0.1 });
  const mesh = new THREE.Mesh(new THREE.BoxGeometry(...size), mat);
  const shape = new CANNON.Box(new CANNON.Vec3(size[0] / 2, size[1] / 2, size[2] / 2));
  return staticBody(world, scene, mesh, shape, position, opts.quaternion);
}

export function buildWorld(world, scene) {
  const stations = [];
  const waterZones = [];

  buildGroundAndSky(world, scene);
  buildBoundary(world, scene);

  const layout = [
    { name: 'Shooting Range', x: -44, z: 0, build: buildShootingRange },
    { name: 'Ragdoll Arena', x: -22, z: 0, build: buildRagdollArena },
    { name: 'Melee Dojo', x: 22, z: 0, build: buildMeleeDojo },
    { name: 'Demolition Pit', x: 44, z: 0, build: buildDemolitionPit },
    { name: 'Liquid Pool', x: -44, z: 32, build: buildLiquidPool },
    { name: 'Sand Pit', x: -20, z: 32, build: buildSandPit },
    { name: 'Block Tower', x: 20, z: 32, build: buildBlockTower },
    { name: 'Drop Zone', x: 44, z: 32, build: buildDropZone },
    { name: 'Launch Seesaw', x: -22, z: -32, build: buildSeesaw },
    { name: 'Junkyard', x: 22, z: -32, build: buildJunkyard },
  ];

  layout.forEach((entry, i) => {
    const origin = new THREE.Vector3(entry.x, 0, entry.z);
    label(scene, `${i + 1}. ${entry.name}`, new THREE.Vector3(entry.x, 3.2, entry.z));
    const result = entry.build(world, scene, origin) || {};
    if (result.waterZone) waterZones.push(result.waterZone);
    stations.push({ name: entry.name, index: i + 1, origin });
  });

  return { stations, waterZones, spawnPoint: new THREE.Vector3(0, 1.4, 0) };
}

function buildGroundAndSky(world, scene) {
  scene.background = new THREE.Color('#8fb4d9');
  scene.fog = new THREE.Fog('#8fb4d9', 45, 150);

  const groundBody = new CANNON.Body({ mass: 0, material: defaultMaterial });
  groundBody.addShape(new CANNON.Plane());
  groundBody.quaternion.setFromEuler(-Math.PI / 2, 0, 0);
  groundBody.collisionFilterGroup = GROUP.DEFAULT;
  groundBody.collisionFilterMask = GROUP.DEFAULT | GROUP.RAGDOLL | GROUP.PLAYER;
  world.addBody(groundBody);

  const groundMesh = new THREE.Mesh(
    new THREE.PlaneGeometry(WORLD_SIZE * 2, WORLD_SIZE * 2),
    new THREE.MeshStandardMaterial({ map: concreteTexture(60), roughness: 0.95 })
  );
  groundMesh.rotation.x = -Math.PI / 2;
  groundMesh.receiveShadow = true;
  scene.add(groundMesh);

  const sun = new THREE.DirectionalLight('#fff2d8', 3.1);
  sun.position.set(40, 60, 20);
  sun.castShadow = true;
  sun.shadow.mapSize.set(2048, 2048);
  sun.shadow.camera.left = -90;
  sun.shadow.camera.right = 90;
  sun.shadow.camera.top = 90;
  sun.shadow.camera.bottom = -90;
  sun.shadow.camera.far = 200;
  sun.shadow.bias = -0.0015;
  scene.add(sun);
  scene.add(sun.target);

  const hemi = new THREE.HemisphereLight('#bcd8ee', '#5c584a', 0.65);
  scene.add(hemi);
}

function buildBoundary(world, scene) {
  const h = 5;
  const mat = new THREE.MeshStandardMaterial({ map: concreteTexture(20), roughness: 0.9 });
  const sides = [
    { size: [WORLD_SIZE * 2, h, 1], pos: [0, h / 2, -WORLD_SIZE] },
    { size: [WORLD_SIZE * 2, h, 1], pos: [0, h / 2, WORLD_SIZE] },
    { size: [1, h, WORLD_SIZE * 2], pos: [-WORLD_SIZE, h / 2, 0] },
    { size: [1, h, WORLD_SIZE * 2], pos: [WORLD_SIZE, h / 2, 0] },
  ];
  for (const s of sides) {
    box(world, scene, s.size, new THREE.Vector3(...s.pos), { material: mat });
  }
}

// ---------- Station 1: Shooting Range ----------
function buildShootingRange(world, scene, o) {
  const backWall = new THREE.MeshStandardMaterial({ map: concreteTexture(10), roughness: 0.9 });
  box(world, scene, [14, 6, 0.6], new THREE.Vector3(o.x, 3, o.z - 8), { material: backWall });
  box(world, scene, [0.6, 6, 8], new THREE.Vector3(o.x - 7, 3, o.z - 4), { material: backWall });
  box(world, scene, [0.6, 6, 8], new THREE.Vector3(o.x + 7, 3, o.z - 4), { material: backWall });

  const distances = [3.5, 5, 6.5];
  const xs = [-4, 0, 4];
  let d = 0;
  for (const x of xs) {
    spawnTarget(world, scene, new THREE.Vector3(o.x + x, 0.1, o.z - 6.5), Math.PI);
    d++;
  }
  spawnTarget(world, scene, new THREE.Vector3(o.x - 2, 1.5, o.z - 7.2), Math.PI);
  spawnTarget(world, scene, new THREE.Vector3(o.x + 2, 1.9, o.z - 7.5), Math.PI);
}

// ---------- Station 2: Ragdoll Arena ----------
function buildRagdollArena(world, scene, o) {
  const platform = new THREE.MeshStandardMaterial({ map: concreteTexture(6), color: '#9a9d9f', roughness: 0.85 });
  box(world, scene, [16, 0.3, 16], new THREE.Vector3(o.x, -0.15, o.z), { material: platform });
  createDummy(world, scene, new THREE.Vector3(o.x - 2, 1.2, o.z));
  createDummy(world, scene, new THREE.Vector3(o.x + 2, 1.2, o.z + 1));
}

// ---------- Station 3: Melee Dojo ----------
function buildMeleeDojo(world, scene, o) {
  const frameMat = new THREE.MeshStandardMaterial({ map: metalTexture(2), color: '#5a5d61', roughness: 0.6, metalness: 0.6 });
  function hangingBag(x, z) {
    const beamY = 3.4;
    box(world, scene, [0.12, 0.12, 3.4], new THREE.Vector3(x, beamY, z), { material: frameMat });
    box(world, scene, [0.12, beamY, 0.12], new THREE.Vector3(x, beamY / 2, z - 1.6), { material: frameMat });
    box(world, scene, [0.12, beamY, 0.12], new THREE.Vector3(x, beamY / 2, z + 1.6), { material: frameMat });

    const anchor = new CANNON.Body({ mass: 0, position: new CANNON.Vec3(x, beamY, z), material: defaultMaterial });
    world.addBody(anchor);

    const bagBody = new CANNON.Body({ mass: 9, position: new CANNON.Vec3(x, 1.6, z), linearDamping: 0.5, angularDamping: 0.7, material: defaultMaterial });
    bagBody.addShape(new CANNON.Cylinder(0.28, 0.24, 1.3, 12));
    bagBody.collisionFilterGroup = GROUP.DEFAULT;
    bagBody.collisionFilterMask = GROUP.DEFAULT | GROUP.RAGDOLL | GROUP.PLAYER;
    bagBody.userData = { type: 'prop', propType: 'punchbag', health: 999 };
    world.addBody(bagBody);

    const rope = new CANNON.PointToPointConstraint(anchor, new CANNON.Vec3(0, 0, 0), bagBody, new CANNON.Vec3(0, 0.8, 0), 1e6);
    world.addConstraint(rope);

    const bagMesh = new THREE.Mesh(
      new THREE.CylinderGeometry(0.28, 0.24, 1.3, 14),
      new THREE.MeshStandardMaterial({ map: metalTexture(1, '#7a3b2e'), color: '#8b4636', roughness: 0.8 })
    );
    bagMesh.castShadow = true;
    scene.add(bagMesh);
    registerSynced(bagBody, bagMesh);
  }
  hangingBag(o.x - 2.2, o.z);
  hangingBag(o.x + 2.2, o.z);
}

// ---------- Station 4: Demolition Pit ----------
function buildDemolitionPit(world, scene, o) {
  const wallMat = new THREE.MeshStandardMaterial({ map: hazardStripeTexture(3), roughness: 0.7 });
  box(world, scene, [12, 3, 0.5], new THREE.Vector3(o.x, 1.5, o.z - 6), { material: wallMat });
  box(world, scene, [12, 3, 0.5], new THREE.Vector3(o.x, 1.5, o.z + 6), { material: wallMat });
  box(world, scene, [0.5, 3, 12], new THREE.Vector3(o.x - 6, 1.5, o.z), { material: wallMat });
  box(world, scene, [0.5, 3, 12], new THREE.Vector3(o.x + 6, 1.5, o.z), { material: wallMat });

  for (let i = 0; i < 3; i++) {
    spawnBarrel(world, scene, new THREE.Vector3(o.x - 2 + i * 2, 0.5, o.z - 1));
  }
  for (let i = 0; i < 4; i++) {
    spawnCrate(world, scene, new THREE.Vector3(o.x - 1.5 + i, 0.3, o.z + 2));
  }
}

// ---------- Station 5: Liquid Pool ----------
function buildLiquidPool(world, scene, o) {
  const rimMat = new THREE.MeshStandardMaterial({ map: concreteTexture(8), roughness: 0.9 });
  const w = 8;
  const depth = 1.4;
  box(world, scene, [w, depth, 0.4], new THREE.Vector3(o.x, -depth / 2, o.z - w / 2), { material: rimMat });
  box(world, scene, [w, depth, 0.4], new THREE.Vector3(o.x, -depth / 2, o.z + w / 2), { material: rimMat });
  box(world, scene, [0.4, depth, w], new THREE.Vector3(o.x - w / 2, -depth / 2, o.z), { material: rimMat });
  box(world, scene, [0.4, depth, w], new THREE.Vector3(o.x + w / 2, -depth / 2, o.z), { material: rimMat });
  box(world, scene, [w, 0.2, w], new THREE.Vector3(o.x, -depth, o.z), { material: rimMat });

  const waterMesh = new THREE.Mesh(
    new THREE.PlaneGeometry(w - 0.4, w - 0.4),
    new THREE.MeshPhysicalMaterial({ color: '#2f7fb8', transparent: true, opacity: 0.72, roughness: 0.15, metalness: 0, transmission: 0.35, thickness: 0.6 })
  );
  waterMesh.rotation.x = -Math.PI / 2;
  waterMesh.position.set(o.x, -0.35, o.z);
  scene.add(waterMesh);

  return {
    waterZone: { minX: o.x - w / 2 + 0.3, maxX: o.x + w / 2 - 0.3, minZ: o.z - w / 2 + 0.3, maxZ: o.z + w / 2 - 0.3, surfaceY: -0.35 },
  };
}

// ---------- Station 6: Sand Pit ----------
function buildSandPit(world, scene, o) {
  const rimMat = new THREE.MeshStandardMaterial({ map: concreteTexture(6), roughness: 0.9 });
  const w = 7;
  box(world, scene, [w, 0.9, 0.3], new THREE.Vector3(o.x, 0.1, o.z - w / 2), { material: rimMat });
  box(world, scene, [w, 0.9, 0.3], new THREE.Vector3(o.x, 0.1, o.z + w / 2), { material: rimMat });
  box(world, scene, [0.3, 0.9, w], new THREE.Vector3(o.x - w / 2, 0.1, o.z), { material: rimMat });
  box(world, scene, [0.3, 0.9, w], new THREE.Vector3(o.x + w / 2, 0.1, o.z), { material: rimMat });

  const floor = new THREE.Mesh(new THREE.PlaneGeometry(w, w), new THREE.MeshStandardMaterial({ map: sandTexture(10), roughness: 1 }));
  floor.rotation.x = -Math.PI / 2;
  floor.position.set(o.x, -0.02, o.z);
  scene.add(floor);

  const sandTex = sandTexture(1);
  let count = 0;
  for (let x = -2.2; x <= 2.2; x += 0.26) {
    for (let z = -2.2; z <= 2.2; z += 0.26) {
      if (count++ > 170) continue;
      spawnSandParticle(world, scene, new THREE.Vector3(o.x + x, 0.3 + Math.random() * 1.5, o.z + z), sandTex);
    }
  }
}

// ---------- Station 7: Block Tower ----------
function buildBlockTower(world, scene, o) {
  const floorMat = new THREE.MeshStandardMaterial({ map: concreteTexture(5), roughness: 0.9 });
  box(world, scene, [7, 0.2, 7], new THREE.Vector3(o.x, -0.1, o.z), { material: floorMat });

  let level = 0;
  for (let y = 0; y < 5; y++) {
    const perRow = 5 - y;
    for (let i = 0; i < perRow; i++) {
      const x = o.x + (i - (perRow - 1) / 2) * 0.6;
      spawnCrate(world, scene, new THREE.Vector3(x, 0.3 + y * 0.58, o.z));
      level++;
    }
  }
  spawnCrate(world, scene, new THREE.Vector3(o.x - 2.5, 0.3, o.z + 2));
  spawnCrate(world, scene, new THREE.Vector3(o.x - 1.8, 0.3, o.z + 2));
}

// ---------- Station 8: Drop Zone ----------
function buildDropZone(world, scene, o) {
  const towerMat = new THREE.MeshStandardMaterial({ map: concreteTexture(4), roughness: 0.85 });
  const towerHeight = 9;
  box(world, scene, [4, towerHeight, 4], new THREE.Vector3(o.x + 3, towerHeight / 2, o.z), { material: towerMat });

  const stepMat = new THREE.MeshStandardMaterial({ map: metalTexture(2), color: '#6c6f73', roughness: 0.6, metalness: 0.5 });
  const steps = 14;
  for (let i = 0; i < steps; i++) {
    const t = i / steps;
    const angle = t * Math.PI * 1.6;
    const r = 3.4;
    const x = o.x + 3 + Math.cos(angle) * r;
    const z = o.z + Math.sin(angle) * r;
    box(world, scene, [1.3, 0.25, 1.1], new THREE.Vector3(x, 0.3 + t * towerHeight, z), { material: stepMat, quaternion: new THREE.Quaternion().setFromEuler(new THREE.Euler(0, -angle, 0)) });
  }
  box(world, scene, [3.6, 0.25, 3.6], new THREE.Vector3(o.x + 3, towerHeight + 0.15, o.z), { material: stepMat });

  const railMat = new THREE.MeshStandardMaterial({ color: '#f0b429', roughness: 0.5 });
  box(world, scene, [3.6, 0.9, 0.08], new THREE.Vector3(o.x + 3, towerHeight + 0.9, o.z - 1.8), { material: railMat });
}

// ---------- Station 9: Seesaw ----------
function buildSeesaw(world, scene, o) {
  const fulcrumMat = new THREE.MeshStandardMaterial({ map: concreteTexture(3), roughness: 0.85 });
  box(world, scene, [1, 0.9, 1.4], new THREE.Vector3(o.x, 0.45, o.z), { material: fulcrumMat });

  const plankLen = 6.5;
  const plankBody = new CANNON.Body({ mass: 20, position: new CANNON.Vec3(o.x, 0.95, o.z), angularDamping: 0.6, linearDamping: 0.3, material: defaultMaterial });
  plankBody.addShape(new CANNON.Box(new CANNON.Vec3(plankLen / 2, 0.12, 0.9)));
  plankBody.collisionFilterGroup = GROUP.DEFAULT;
  plankBody.collisionFilterMask = GROUP.DEFAULT | GROUP.RAGDOLL | GROUP.PLAYER;
  plankBody.userData = { type: 'prop', propType: 'seesaw' };
  world.addBody(plankBody);

  const pivot = new CANNON.Body({ mass: 0, position: new CANNON.Vec3(o.x, 0.95, o.z), material: defaultMaterial });
  world.addBody(pivot);
  const hinge = new CANNON.HingeConstraint(pivot, plankBody, {
    pivotA: new CANNON.Vec3(0, 0, 0),
    pivotB: new CANNON.Vec3(0, 0, 0),
    axisA: new CANNON.Vec3(0, 0, 1),
    axisB: new CANNON.Vec3(0, 0, 1),
    collideConnected: false,
  });
  world.addConstraint(hinge);

  const plankMesh = new THREE.Mesh(
    new THREE.BoxGeometry(plankLen, 0.24, 1.8),
    new THREE.MeshStandardMaterial({ map: metalTexture(3), color: '#c94a3c', roughness: 0.55, metalness: 0.4 })
  );
  plankMesh.castShadow = true;
  scene.add(plankMesh);
  registerSynced(plankBody, plankMesh);

  spawnCrate(world, scene, new THREE.Vector3(o.x - 2.6, 3, o.z));
}

// ---------- Station 10: Junkyard ----------
function buildJunkyard(world, scene, o) {
  const floorMat = new THREE.MeshStandardMaterial({ map: concreteTexture(6), color: '#79766c', roughness: 0.95 });
  box(world, scene, [10, 0.2, 10], new THREE.Vector3(o.x, -0.1, o.z), { material: floorMat });

  const rnd = (a, b) => a + Math.random() * (b - a);
  for (let i = 0; i < 5; i++) spawnBarrel(world, scene, new THREE.Vector3(o.x + rnd(-3.5, 3.5), 0.5, o.z + rnd(-3.5, 3.5)));
  for (let i = 0; i < 6; i++) spawnCrate(world, scene, new THREE.Vector3(o.x + rnd(-3.5, 3.5), 0.3, o.z + rnd(-3.5, 3.5)));
  for (let i = 0; i < 4; i++) spawnPlank(world, scene, new THREE.Vector3(o.x + rnd(-3.5, 3.5), 0.2, o.z + rnd(-3.5, 3.5)), rnd(0, Math.PI));
}

export function updateWaterZones(waterZones, dt) {
  for (const zone of waterZones) {
    for (const { body } of allSynced()) {
      if (body.mass <= 0) continue;
      const p = body.position;
      if (p.x < zone.minX || p.x > zone.maxX || p.z < zone.minZ || p.z > zone.maxZ) continue;
      if (p.y > zone.surfaceY + 0.6) continue;
      const submersion = Math.min(1, (zone.surfaceY + 0.5 - p.y) / 0.8);
      if (submersion <= 0) continue;
      body.velocity.y += 9.6 * submersion * dt;
      body.velocity.x *= 1 - 0.9 * dt * submersion;
      body.velocity.z *= 1 - 0.9 * dt * submersion;
      body.velocity.y *= 1 - 0.6 * dt * submersion;
      body.angularVelocity.scale(1 - 0.5 * dt * submersion, body.angularVelocity);
    }
  }
}

