import * as THREE from 'three';
import * as CANNON from 'cannon-es';
import { GROUP, defaultMaterial } from './physics.js';
import { woodTexture, metalTexture, crateLabelTexture } from './textures.js';

// Every spawned physics object in the game (props, ragdoll parts, targets)
// goes through this registry so a single render loop can keep meshes in
// sync with bodies, and so weapon hit logic can find "what did I hit"
// starting only from a cannon Body.
const synced = [];

export function registerSynced(body, mesh) {
  synced.push({ body, mesh });
}

export function unregisterSynced(body) {
  const i = synced.findIndex((s) => s.body === body);
  if (i !== -1) synced.splice(i, 1);
}

export function syncMeshes() {
  for (const { body, mesh } of synced) {
    mesh.position.set(body.position.x, body.position.y, body.position.z);
    mesh.quaternion.set(body.quaternion.x, body.quaternion.y, body.quaternion.z, body.quaternion.w);
  }
}

export function allSynced() {
  return synced;
}

let woodTex, metalTex, labelTex;
function textures() {
  if (!woodTex) {
    woodTex = woodTexture(1.5);
    metalTex = metalTexture(2);
    labelTex = crateLabelTexture();
  }
  return { woodTex, metalTex, labelTex };
}

function addBody(world, scene, body, mesh, extraTag) {
  body.material = body.material || defaultMaterial;
  body.collisionFilterGroup = GROUP.DEFAULT;
  body.collisionFilterMask = GROUP.DEFAULT | GROUP.RAGDOLL;
  body.userData = Object.assign({ type: 'prop' }, extraTag);
  world.addBody(body);
  scene.add(mesh);
  mesh.castShadow = true;
  mesh.receiveShadow = true;
  registerSynced(body, mesh);
  return { body, mesh };
}

export function spawnCrate(world, scene, position) {
  const { woodTex, labelTex } = textures();
  const size = 0.55;
  const body = new CANNON.Body({ mass: 8, position: new CANNON.Vec3(position.x, position.y, position.z) });
  body.addShape(new CANNON.Box(new CANNON.Vec3(size / 2, size / 2, size / 2)));
  const mats = [woodTex, woodTex, labelTex, woodTex, woodTex, woodTex].map(
    (t) => new THREE.MeshStandardMaterial({ map: t, roughness: 0.85, metalness: 0.02 })
  );
  const mesh = new THREE.Mesh(new THREE.BoxGeometry(size, size, size), mats);
  return addBody(world, scene, body, mesh, { propType: 'crate', health: 30 });
}

export function spawnBarrel(world, scene, position) {
  const { metalTex } = textures();
  const radius = 0.32;
  const height = 0.85;
  const body = new CANNON.Body({ mass: 12, position: new CANNON.Vec3(position.x, position.y, position.z) });
  body.addShape(new CANNON.Cylinder(radius, radius, height, 12));
  const geo = new THREE.CylinderGeometry(radius, radius, height, 16);
  const color = Math.random() > 0.5 ? '#c94a3c' : '#3c6ea5';
  const mat = new THREE.MeshStandardMaterial({ map: metalTex, color, roughness: 0.5, metalness: 0.6 });
  const mesh = new THREE.Mesh(geo, mat);
  return addBody(world, scene, body, mesh, { propType: 'barrel', health: 20, explosive: true });
}

export function spawnPlank(world, scene, position, rotationY = 0) {
  const { woodTex } = textures();
  const dims = [1.4, 0.06, 0.28];
  const body = new CANNON.Body({ mass: 4, position: new CANNON.Vec3(position.x, position.y, position.z) });
  body.quaternion.setFromEuler(0, rotationY, 0);
  body.addShape(new CANNON.Box(new CANNON.Vec3(dims[0] / 2, dims[1] / 2, dims[2] / 2)));
  const mesh = new THREE.Mesh(new THREE.BoxGeometry(...dims), new THREE.MeshStandardMaterial({ map: woodTex, roughness: 0.8 }));
  return addBody(world, scene, body, mesh, { propType: 'plank', health: 15 });
}

export function spawnTarget(world, scene, position, facingY = 0) {
  const group = new THREE.Group();
  const postMat = new THREE.MeshStandardMaterial({ color: '#2b2d30', roughness: 0.6, metalness: 0.4 });
  const post = new THREE.Mesh(new THREE.CylinderGeometry(0.04, 0.04, 1.1, 8), postMat);
  post.position.y = -0.55;
  group.add(post);

  const ringGeo = new THREE.CircleGeometry(0.4, 32);
  const canvasTex = ringTexture();
  const face = new THREE.Mesh(ringGeo, new THREE.MeshStandardMaterial({ map: canvasTex, roughness: 0.7, side: THREE.DoubleSide }));
  face.position.y = 0.05;
  group.add(face);

  group.position.set(position.x, position.y + 1.1, position.z);
  group.rotation.y = facingY;

  const body = new CANNON.Body({ mass: 6, position: new CANNON.Vec3(position.x, position.y + 1.1, position.z) });
  body.quaternion.setFromEuler(0, facingY, 0);
  body.addShape(new CANNON.Box(new CANNON.Vec3(0.42, 0.42, 0.05)));
  body.addShape(new CANNON.Box(new CANNON.Vec3(0.05, 0.55, 0.05)), new CANNON.Vec3(0, -0.55, 0));
  body.angularDamping = 0.9;
  body.linearDamping = 0.5;

  return addBody(world, scene, body, group, { propType: 'target', health: 100 });
}

function ringTexture() {
  const c = document.createElement('canvas');
  c.width = c.height = 256;
  const ctx = c.getContext('2d');
  ctx.fillStyle = '#eae7dc';
  ctx.fillRect(0, 0, 256, 256);
  const rings = [
    [110, '#d6453f'],
    [85, '#eae7dc'],
    [60, '#d6453f'],
    [35, '#eae7dc'],
    [14, '#151515'],
  ];
  for (const [r, color] of rings) {
    ctx.beginPath();
    ctx.arc(128, 128, r, 0, Math.PI * 2);
    ctx.fillStyle = color;
    ctx.fill();
  }
  const tex = new THREE.CanvasTexture(c);
  tex.colorSpace = THREE.SRGBColorSpace;
  return tex;
}

export function spawnSandParticle(world, scene, position, sandTex) {
  const r = 0.05 + Math.random() * 0.02;
  const body = new CANNON.Body({ mass: 0.15, position: new CANNON.Vec3(position.x, position.y, position.z) });
  body.addShape(new CANNON.Sphere(r));
  body.linearDamping = 0.4;
  body.angularDamping = 0.6;
  const mesh = new THREE.Mesh(new THREE.SphereGeometry(r, 6, 6), new THREE.MeshStandardMaterial({ map: sandTex, roughness: 1 }));
  return addBody(world, scene, body, mesh, { propType: 'sand' });
}

export function removeProp(world, scene, entry) {
  world.removeBody(entry.body);
  scene.remove(entry.mesh);
  unregisterSynced(entry.body);
}
