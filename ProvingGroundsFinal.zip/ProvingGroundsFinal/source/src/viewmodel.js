import * as THREE from 'three';

const REST_POS = new THREE.Vector3(0.26, -0.26, -0.5);
const AIM_POS = new THREE.Vector3(0, -0.15, -0.32);
const AIM_TRANSITION_RATE = 11; // per second, exponential

export function createViewmodel(camera) {
  const rig = new THREE.Group();
  rig.position.copy(REST_POS);
  camera.add(rig);

  const glove = new THREE.MeshStandardMaterial({ color: '#2a2c2f', roughness: 0.75, metalness: 0.05 });
  const forearm = new THREE.Mesh(new THREE.CylinderGeometry(0.045, 0.055, 0.34, 10), glove);
  forearm.rotation.x = Math.PI / 2.1;
  forearm.position.set(0.02, -0.06, 0.22);
  rig.add(forearm);

  const hand = new THREE.Mesh(new THREE.BoxGeometry(0.09, 0.07, 0.11), glove);
  hand.position.set(0, -0.02, 0.02);
  rig.add(hand);

  const thumb = new THREE.Mesh(new THREE.BoxGeometry(0.03, 0.03, 0.06), glove);
  thumb.position.set(0.06, 0.01, 0.03);
  rig.add(thumb);

  const weaponSlot = new THREE.Group();
  weaponSlot.position.set(-0.02, 0.02, -0.08);
  rig.add(weaponSlot);

  let currentMesh = null;
  let currentWeapon = null;
  let recoil = 0;
  let swingT = -1;
  let swingDuration = 0.3;
  let reloadT = -1;
  let reloadDuration = 1;
  let bobPhase = 0;
  let aimTarget = 0;
  let aimFrac = 0;

  function setWeapon(weapon) {
    if (currentMesh) weaponSlot.remove(currentMesh);
    currentMesh = weapon.mesh();
    currentWeapon = weapon;
    weaponSlot.add(currentMesh);
    recoil = 0;
    swingT = -1;
    reloadT = -1;
    aimTarget = 0;
    aimFrac = 0;
  }

  function setAiming(isAiming) {
    aimTarget = isAiming ? 1 : 0;
  }

  function setHidden(hidden) {
    rig.visible = !hidden;
  }

  function triggerRecoil() {
    recoil = 1;
  }

  function triggerSwing(duration) {
    swingDuration = duration;
    swingT = 0;
  }

  function triggerReload(duration) {
    reloadDuration = duration;
    reloadT = 0;
  }

  function getMuzzleWorldPosition() {
    const local = (currentMesh && currentMesh.userData.muzzleLocalPos) || new THREE.Vector3(0, 0, -0.4);
    return weaponSlot.localToWorld(local.clone());
  }

  function update(dt, { speed = 0, grounded = true } = {}) {
    aimFrac += (aimTarget - aimFrac) * (1 - Math.exp(-AIM_TRANSITION_RATE * dt));

    // idle breathing sway, damped down while aiming for a steadier sighted feel
    const swayAmount = 1 - aimFrac * 0.85;
    const t = performance.now() * 0.001;
    const basePos = REST_POS.clone().lerp(AIM_POS, aimFrac);
    let x = basePos.x + Math.sin(t * 0.9) * 0.004 * swayAmount;
    let y = basePos.y + Math.sin(t * 1.3) * 0.004 * swayAmount;
    let z = basePos.z;

    // walk bob, also damped while aiming
    if (speed > 0.2 && grounded) {
      bobPhase += dt * speed * 1.6;
      x += Math.sin(bobPhase) * 0.012 * swayAmount;
      y += Math.abs(Math.sin(bobPhase * 1.0)) * 0.014 * swayAmount;
    }

    rig.position.set(x, y, z);

    // recoil: quick kick back, spring return
    if (recoil > 0.001) {
      weaponSlot.position.z = -0.08 - recoil * 0.09;
      weaponSlot.rotation.x = -recoil * 0.18;
      recoil *= Math.max(0, 1 - dt * 14);
    } else {
      weaponSlot.position.z = -0.08;
      weaponSlot.rotation.x = 0;
    }

    // melee swing arc
    if (swingT >= 0) {
      swingT += dt;
      const p = Math.min(1, swingT / swingDuration);
      const arc = Math.sin(p * Math.PI);
      weaponSlot.rotation.y = -0.9 * arc;
      weaponSlot.rotation.z = 0.5 * arc;
      weaponSlot.position.x = -0.02 - arc * 0.1;
      if (p >= 1) {
        swingT = -1;
        weaponSlot.rotation.y = 0;
        weaponSlot.rotation.z = 0;
        weaponSlot.position.x = -0.02;
      }
    }

    // reload dip
    if (reloadT >= 0) {
      reloadT += dt;
      const p = Math.min(1, reloadT / reloadDuration);
      const dip = Math.sin(p * Math.PI);
      rig.position.y -= dip * 0.09;
      rig.rotation.x = dip * 0.35;
      if (p >= 1) {
        reloadT = -1;
        rig.rotation.x = 0;
      }
    } else {
      rig.rotation.x = 0;
    }
  }

  return { group: rig, setWeapon, update, setAiming, setHidden, triggerRecoil, triggerSwing, triggerReload, getMuzzleWorldPosition };
}
