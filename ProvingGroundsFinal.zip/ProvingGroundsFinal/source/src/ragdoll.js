import * as CANNON from 'cannon-es';
import { GROUP, defaultMaterial } from './physics.js';

// Blocky ragdoll dummy: 11 rigid parts (head, torso, pelvis, 2x upper/lower
// arm, 2x upper/lower leg) held together with cone twist joints at the
// ball style joints (neck, waist, shoulders, hips) and hinge joints at the
// elbows and knees, matching how real limbs actually bend.
//
// Kept dependency free (cannon-es only, no THREE, no DOM) so it can run and
// be verified in plain Node without a browser.

export const RAGDOLL_DIMS = {
  pelvis: [0.36, 0.26, 0.24],
  torso: [0.42, 0.5, 0.24],
  head: [0.26, 0.28, 0.26],
  upperArm: [0.14, 0.32, 0.14],
  lowerArm: [0.12, 0.3, 0.12],
  upperLeg: [0.18, 0.42, 0.18],
  lowerLeg: [0.15, 0.4, 0.15],
};

let nextRagdollId = 1;

export function createRagdoll(world, position = new CANNON.Vec3(0, 2, 0)) {
  const ragdollId = nextRagdollId++;
  const d = RAGDOLL_DIMS;
  const parts = {};
  const bodies = [];
  const constraints = [];

  function box(name, sx, sy, sz, mass, x, y, z) {
    const body = new CANNON.Body({
      mass,
      position: new CANNON.Vec3(position.x + x, position.y + y, position.z + z),
      linearDamping: 0.2,
      angularDamping: 0.7,
      material: defaultMaterial,
    });
    body.addShape(new CANNON.Box(new CANNON.Vec3(sx / 2, sy / 2, sz / 2)));
    body.collisionFilterGroup = GROUP.RAGDOLL;
    body.collisionFilterMask = GROUP.DEFAULT;
    body.userData = { type: 'ragdoll', part: name, ragdollId, size: [sx, sy, sz] };
    world.addBody(body);
    parts[name] = body;
    bodies.push(body);
    return body;
  }

  // Standing pose, built bottom up. All Y values are relative to the feet
  // (the position passed in is treated as ground contact height).
  const lowerLegY = d.lowerLeg[1] / 2;
  const kneeY = d.lowerLeg[1];
  const upperLegY = kneeY + d.upperLeg[1] / 2;
  const hipY = kneeY + d.upperLeg[1];
  const pelvisY = hipY + d.pelvis[1] / 2;
  const torsoY = hipY + d.pelvis[1] + d.torso[1] / 2;
  const shoulderY = hipY + d.pelvis[1] + d.torso[1];
  const upperArmY = shoulderY - d.upperArm[1] / 2;
  const elbowY = shoulderY - d.upperArm[1];
  const lowerArmY = elbowY - d.lowerArm[1] / 2;
  const headY = shoulderY + d.head[1] / 2;

  const legX = 0.11;
  const armX = d.torso[0] / 2 + d.upperArm[0] / 2 + 0.02;

  box('pelvis', ...d.pelvis, 4, 0, pelvisY, 0);
  box('torso', ...d.torso, 6, 0, torsoY, 0);
  box('head', ...d.head, 1.2, 0, headY, 0);

  box('upperLegL', ...d.upperLeg, 1.6, -legX, upperLegY, 0);
  box('lowerLegL', ...d.lowerLeg, 1.1, -legX, lowerLegY, 0);
  box('upperLegR', ...d.upperLeg, 1.6, legX, upperLegY, 0);
  box('lowerLegR', ...d.lowerLeg, 1.1, legX, lowerLegY, 0);

  box('upperArmL', ...d.upperArm, 0.9, -armX, upperArmY, 0);
  box('lowerArmL', ...d.lowerArm, 0.6, -armX, lowerArmY, 0);
  box('upperArmR', ...d.upperArm, 0.9, armX, upperArmY, 0);
  box('lowerArmR', ...d.lowerArm, 0.6, armX, lowerArmY, 0);

  function coneTwist(a, b, pivotA, pivotB, axisA, axisB, angle, twistAngle = 0.6) {
    const c = new CANNON.ConeTwistConstraint(a, b, {
      pivotA: new CANNON.Vec3(...pivotA),
      pivotB: new CANNON.Vec3(...pivotB),
      axisA: new CANNON.Vec3(...axisA),
      axisB: new CANNON.Vec3(...axisB),
      angle,
      twistAngle,
      collideConnected: false,
    });
    world.addConstraint(c);
    constraints.push(c);
    return c;
  }

  function hinge(a, b, pivotA, pivotB, axisA, axisB) {
    const c = new CANNON.HingeConstraint(a, b, {
      pivotA: new CANNON.Vec3(...pivotA),
      pivotB: new CANNON.Vec3(...pivotB),
      axisA: new CANNON.Vec3(...axisA),
      axisB: new CANNON.Vec3(...axisB),
      collideConnected: false,
    });
    world.addConstraint(c);
    constraints.push(c);
    return c;
  }

  // Waist and neck: ball style joints with a moderate cone so the torso
  // cannot bend impossibly far.
  coneTwist(parts.pelvis, parts.torso, [0, d.pelvis[1] / 2, 0], [0, -d.torso[1] / 2, 0], [0, 1, 0], [0, 1, 0], 0.45);
  coneTwist(parts.torso, parts.head, [0, d.torso[1] / 2, 0], [0, -d.head[1] / 2, 0], [0, 1, 0], [0, 1, 0], 0.55);

  // Shoulders
  coneTwist(parts.torso, parts.upperArmL, [-d.torso[0] / 2, d.torso[1] * 0.32, 0], [0, d.upperArm[1] / 2, 0], [1, 0, 0], [0, 1, 0], 1.5);
  coneTwist(parts.torso, parts.upperArmR, [d.torso[0] / 2, d.torso[1] * 0.32, 0], [0, d.upperArm[1] / 2, 0], [1, 0, 0], [0, 1, 0], 1.5);

  // Elbows (single axis hinge)
  hinge(parts.upperArmL, parts.lowerArmL, [0, -d.upperArm[1] / 2, 0], [0, d.lowerArm[1] / 2, 0], [1, 0, 0], [1, 0, 0]);
  hinge(parts.upperArmR, parts.lowerArmR, [0, -d.upperArm[1] / 2, 0], [0, d.lowerArm[1] / 2, 0], [1, 0, 0], [1, 0, 0]);

  // Hips
  coneTwist(parts.pelvis, parts.upperLegL, [-legX, -d.pelvis[1] / 2, 0], [0, d.upperLeg[1] / 2, 0], [0, 1, 0], [0, 1, 0], 0.85);
  coneTwist(parts.pelvis, parts.upperLegR, [legX, -d.pelvis[1] / 2, 0], [0, d.upperLeg[1] / 2, 0], [0, 1, 0], [0, 1, 0], 0.85);

  // Knees (single axis hinge)
  hinge(parts.upperLegL, parts.lowerLegL, [0, -d.upperLeg[1] / 2, 0], [0, d.lowerLeg[1] / 2, 0], [1, 0, 0], [1, 0, 0]);
  hinge(parts.upperLegR, parts.lowerLegR, [0, -d.upperLeg[1] / 2, 0], [0, d.lowerLeg[1] / 2, 0], [1, 0, 0], [1, 0, 0]);

  for (const b of bodies) b.userData.ragdollBodies = bodies;

  return { id: ragdollId, parts, bodies, constraints };
}

export function removeRagdoll(world, ragdoll) {
  for (const c of ragdoll.constraints) world.removeConstraint(c);
  for (const b of ragdoll.bodies) world.removeBody(b);
}
