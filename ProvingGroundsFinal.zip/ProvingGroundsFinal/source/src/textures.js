import * as THREE from 'three';

function canvas(size = 256) {
  const c = document.createElement('canvas');
  c.width = size;
  c.height = size;
  return c;
}

function noise(ctx, size, amount, tone = 0) {
  const img = ctx.getImageData(0, 0, size, size);
  const d = img.data;
  for (let i = 0; i < d.length; i += 4) {
    const n = (Math.random() - 0.5) * amount;
    d[i] = Math.min(255, Math.max(0, d[i] + n + tone));
    d[i + 1] = Math.min(255, Math.max(0, d[i + 1] + n + tone));
    d[i + 2] = Math.min(255, Math.max(0, d[i + 2] + n + tone));
  }
  ctx.putImageData(img, 0, 0);
}

function finish(c, repeat = 1) {
  const tex = new THREE.CanvasTexture(c);
  tex.wrapS = tex.wrapT = THREE.RepeatWrapping;
  tex.repeat.set(repeat, repeat);
  tex.anisotropy = 8;
  tex.colorSpace = THREE.SRGBColorSpace;
  return tex;
}

export function concreteTexture(repeat = 48) {
  const size = 256;
  const c = canvas(size);
  const ctx = c.getContext('2d');
  ctx.fillStyle = '#83868a';
  ctx.fillRect(0, 0, size, size);
  noise(ctx, size, 26);
  ctx.strokeStyle = 'rgba(20,20,22,0.35)';
  ctx.lineWidth = 2;
  const cell = 32;
  for (let i = 0; i <= size; i += cell) {
    ctx.beginPath();
    ctx.moveTo(i, 0);
    ctx.lineTo(i, size);
    ctx.stroke();
    ctx.beginPath();
    ctx.moveTo(0, i);
    ctx.lineTo(size, i);
    ctx.stroke();
  }
  return finish(c, repeat);
}

export function hazardStripeTexture(repeat = 6) {
  const size = 128;
  const c = canvas(size);
  const ctx = c.getContext('2d');
  ctx.fillStyle = '#151515';
  ctx.fillRect(0, 0, size, size);
  ctx.fillStyle = '#f0b429';
  const stripe = 22;
  ctx.save();
  ctx.translate(size / 2, size / 2);
  ctx.rotate(Math.PI / 4);
  ctx.translate(-size, -size);
  for (let i = -size; i < size * 3; i += stripe * 2) {
    ctx.fillRect(i, -size, stripe, size * 4);
  }
  ctx.restore();
  return finish(c, repeat);
}

export function metalTexture(repeat = 4, base = '#9aa0a6') {
  const size = 128;
  const c = canvas(size);
  const ctx = c.getContext('2d');
  ctx.fillStyle = base;
  ctx.fillRect(0, 0, size, size);
  for (let i = 0; i < size; i += 3) {
    ctx.fillStyle = `rgba(255,255,255,${Math.random() * 0.05})`;
    ctx.fillRect(0, i, size, 1);
  }
  noise(ctx, size, 14);
  return finish(c, repeat);
}

export function woodTexture(repeat = 2) {
  const size = 128;
  const c = canvas(size);
  const ctx = c.getContext('2d');
  ctx.fillStyle = '#8a5a34';
  ctx.fillRect(0, 0, size, size);
  for (let i = 0; i < 40; i++) {
    const y = Math.random() * size;
    ctx.strokeStyle = `rgba(60,35,15,${0.15 + Math.random() * 0.2})`;
    ctx.lineWidth = 1 + Math.random() * 2;
    ctx.beginPath();
    ctx.moveTo(0, y);
    ctx.bezierCurveTo(size * 0.3, y + (Math.random() - 0.5) * 12, size * 0.7, y + (Math.random() - 0.5) * 12, size, y);
    ctx.stroke();
  }
  noise(ctx, size, 10);
  return finish(c, repeat);
}

export function sandTexture(repeat = 20) {
  const size = 128;
  const c = canvas(size);
  const ctx = c.getContext('2d');
  ctx.fillStyle = '#cdb26a';
  ctx.fillRect(0, 0, size, size);
  noise(ctx, size, 24, 4);
  return finish(c, repeat);
}

export function crateLabelTexture() {
  const size = 256;
  const c = canvas(size);
  const ctx = c.getContext('2d');
  ctx.fillStyle = '#a3703c';
  ctx.fillRect(0, 0, size, size);
  noise(ctx, size, 16);
  ctx.strokeStyle = 'rgba(40,24,10,0.5)';
  ctx.lineWidth = 6;
  ctx.strokeRect(10, 10, size - 20, size - 20);
  ctx.fillStyle = 'rgba(30,16,6,0.55)';
  ctx.font = 'bold 26px sans-serif';
  ctx.textAlign = 'center';
  ctx.save();
  ctx.translate(size / 2, size / 2);
  ctx.rotate(-0.06);
  ctx.fillText('FRAGILE', 0, -10);
  ctx.fillText('HANDLE W/ CARE', 0, 24);
  ctx.restore();
  const tex = new THREE.CanvasTexture(c);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.anisotropy = 8;
  return tex;
}

export function makeLabelSprite(text, { bg = 'rgba(10,11,13,0.85)', fg = '#f0b429', scale = 1 } = {}) {
  const c = canvas(256);
  c.width = 512;
  c.height = 128;
  const ctx = c.getContext('2d');
  ctx.fillStyle = bg;
  ctx.fillRect(0, 0, c.width, c.height);
  ctx.strokeStyle = fg;
  ctx.lineWidth = 4;
  ctx.strokeRect(4, 4, c.width - 8, c.height - 8);
  ctx.fillStyle = fg;
  ctx.font = 'bold 54px Arial Narrow, Arial, sans-serif';
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.fillText(text.toUpperCase(), c.width / 2, c.height / 2);
  const tex = new THREE.CanvasTexture(c);
  tex.colorSpace = THREE.SRGBColorSpace;
  const mat = new THREE.SpriteMaterial({ map: tex, depthWrite: false, transparent: true });
  const sprite = new THREE.Sprite(mat);
  sprite.scale.set(3.4 * scale, 0.85 * scale, 1);
  return sprite;
}
