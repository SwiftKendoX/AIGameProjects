import * as THREE from 'three';
import * as CANNON from 'cannon-es';
import { GROUP } from './physics.js';
import { spawnCrate, spawnBarrel, spawnPlank, spawnTarget, removeProp } from './props.js';
import { createDummy } from './dummy.js';

function deviceMesh(accentColor) {
  const g = new THREE.Group();
  const body = new THREE.Mesh(new THREE.BoxGeometry(0.09, 0.14, 0.04), new THREE.MeshStandardMaterial({ color: '#2c2e31', roughness: 0.6, metalness: 0.3 }));
  g.add(body);
  const screen = new THREE.Mesh(new THREE.BoxGeometry(0.06, 0.05, 0.01), new THREE.MeshBasicMaterial({ color: accentColor }));
  screen.position.set(0, 0.03, 0.025);
  g.add(screen);
  const grip = new THREE.Mesh(new THREE.CylinderGeometry(0.018, 0.018, 0.1, 8), new THREE.MeshStandardMaterial({ color: '#1c1d1f', roughness: 0.8 }));
  grip.position.set(0, -0.11, 0);
  g.add(grip);
  return g;
}

export const SPAWNERS = [
  { id: 'spawn_dummy', name: 'Dummy', category: 'spawn', kind: 'dummy', mesh: () => deviceMesh('#f2b400') },
  { id: 'spawn_crate', name: 'Crate', category: 'spawn', kind: 'crate', mesh: () => deviceMesh('#a3703c') },
  { id: 'spawn_barrel', name: 'Barrel', category: 'spawn', kind: 'barrel', mesh: () => deviceMesh('#c94a3c') },
  { id: 'spawn_target', name: 'Target', category: 'spawn', kind: 'target', mesh: () => deviceMesh('#d6453f') },
  { id: 'spawn_plank', name: 'Plank', category: 'spawn', kind: 'plank', mesh: () => deviceMesh('#8a5a34') },
];

const COOLDOWN = 0.35;
const MIN_DIST_FROM_PLAYER = 1.6;
const MAX_SPAWNED_PROPS = 25;
const lastSpawn = {};
for (const s of SPAWNERS) lastSpawn[s.id] = -999;
const spawnedProps = [];

export function spawnerCooldownFrac(id, time) {
  return Math.min(1, (time - lastSpawn[id]) / COOLDOWN);
}

export function spawnedPropCount() {
  return spawnedProps.length;
}

// Same interaction pattern as fireGun: aim, click, something happens at the
// point you're looking at. Ray forward to find a surface to spawn on top
// of; if nothing is close enough in front of you, drop it a fixed distance
// ahead instead of spawning it inside a wall.
//
// Whatever position that produces, it is then always checked against the
// player's actual body position and pushed further away if needed. This
// matters: spawning something overlapping the player gets resolved by the
// physics engine as a hard separation push, which is what "everything
// teleports" turned out to actually be. The raycast logic below is what
// picks a sensible spot; the distance check after it is what guarantees
// safety regardless of aim angle, including looking straight down.
export function trySpawn(spawner, ctx) {
  if (ctx.time - lastSpawn[spawner.id] < COOLDOWN) return null;
  lastSpawn[spawner.id] = ctx.time;

  const origin = ctx.camera.getWorldPosition(new THREE.Vector3());
  const dir = ctx.camera.getWorldDirection(new THREE.Vector3());
  const from = new CANNON.Vec3(origin.x, origin.y, origin.z);
  const to = new CANNON.Vec3(origin.x + dir.x * 40, origin.y + dir.y * 40, origin.z + dir.z * 40);
  const result = new CANNON.RaycastResult();
  ctx.world.raycastClosest(from, to, { collisionFilterMask: GROUP.DEFAULT }, result);

  let pos;
  if (result.hasHit && result.distance > MIN_DIST_FROM_PLAYER) {
    pos = new THREE.Vector3(result.hitPointWorld.x, result.hitPointWorld.y + 0.35, result.hitPointWorld.z);
  } else {
    // Nothing hit, or it was too close to place something on top of
    // safely. Flatten the direction so looking down (or up) doesn't
    // collapse the spawn point toward the player's own XZ position.
    const flatDir = new THREE.Vector3(dir.x, 0, dir.z);
    if (flatDir.lengthSq() < 0.02) flatDir.set(0, 0, -1);
    else flatDir.normalize();
    pos = origin.clone().addScaledVector(flatDir, MIN_DIST_FROM_PLAYER + 1.5);
    pos.y = Math.max(0.6, origin.y - 1.2);
  }

  if (ctx.playerBody) {
    const px = ctx.playerBody.position.x;
    const pz = ctx.playerBody.position.z;
    const dx = pos.x - px;
    const dz = pos.z - pz;
    const flatDist = Math.hypot(dx, dz);
    if (flatDist < MIN_DIST_FROM_PLAYER) {
      const pushDir = flatDist > 0.01 ? { x: dx / flatDist, z: dz / flatDist } : { x: 0, z: -1 };
      pos.x = px + pushDir.x * MIN_DIST_FROM_PLAYER;
      pos.z = pz + pushDir.z * MIN_DIST_FROM_PLAYER;
    }
  }

  const yaw = ctx.camera.rotation.y;

  if (spawner.kind === 'dummy') return createDummy(ctx.world, ctx.scene, pos);

  if (spawnedProps.length >= MAX_SPAWNED_PROPS) {
    removeProp(ctx.world, ctx.scene, spawnedProps.shift());
  }
  let entry = null;
  if (spawner.kind === 'crate') entry = spawnCrate(ctx.world, ctx.scene, pos);
  else if (spawner.kind === 'barrel') entry = spawnBarrel(ctx.world, ctx.scene, pos);
  else if (spawner.kind === 'target') entry = spawnTarget(ctx.world, ctx.scene, pos, yaw + Math.PI);
  else if (spawner.kind === 'plank') entry = spawnPlank(ctx.world, ctx.scene, pos, yaw);
  if (entry) spawnedProps.push(entry);
  return entry;
}
