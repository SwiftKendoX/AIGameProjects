import * as THREE from 'three';
import * as CANNON from 'cannon-es';
import { GROUP, playerMaterial } from './physics.js';

const PLAYER_RADIUS = 0.4;
const EYE_HEIGHT = 0.55;
const WALK_SPEED = 4.2;
const SPRINT_MULT = 1.55;
const JUMP_SPEED = 5.6;
const SENSITIVITY = 0.0022;
const RESPONSE_RATE_GROUNDED = 23; // per second; matches the old per-frame feel at 60fps, but scales correctly at any fps
const RESPONSE_RATE_AIR = 2.8;

export function createPlayer(world, camera, domElement, spawnPos = new CANNON.Vec3(0, 3, 0)) {
  const body = new CANNON.Body({
    mass: 70,
    position: spawnPos.clone(),
    fixedRotation: true,
    linearDamping: 0.05,
    material: playerMaterial,
  });
  body.addShape(new CANNON.Sphere(PLAYER_RADIUS));
  body.collisionFilterGroup = GROUP.PLAYER;
  body.collisionFilterMask = GROUP.DEFAULT | GROUP.RAGDOLL;
  world.addBody(body);

  const euler = { yaw: 0, pitch: 0 };
  const keys = { forward: false, back: false, left: false, right: false, sprint: false };
  let jumpQueued = false;
  let grounded = false;
  let speedFrac = 0;

  function onMouseMove(e) {
    if (document.pointerLockElement !== domElement) return;
    euler.yaw -= e.movementX * SENSITIVITY;
    euler.pitch -= e.movementY * SENSITIVITY;
    const lim = Math.PI / 2 - 0.05;
    euler.pitch = Math.max(-lim, Math.min(lim, euler.pitch));
  }

  function onKeyDown(e) {
    setKey(e.code, true);
    if (e.code === 'Space') jumpQueued = true;
  }
  function onKeyUp(e) {
    setKey(e.code, false);
  }
  function setKey(code, val) {
    if (code === 'KeyW' || code === 'ArrowUp') keys.forward = val;
    else if (code === 'KeyS' || code === 'ArrowDown') keys.back = val;
    else if (code === 'KeyA' || code === 'ArrowLeft') keys.left = val;
    else if (code === 'KeyD' || code === 'ArrowRight') keys.right = val;
    else if (code === 'ShiftLeft' || code === 'ShiftRight') keys.sprint = val;
  }

  document.addEventListener('mousemove', onMouseMove);
  document.addEventListener('keydown', onKeyDown);
  document.addEventListener('keyup', onKeyUp);

  function checkGrounded() {
    const from = new CANNON.Vec3(body.position.x, body.position.y, body.position.z);
    const to = new CANNON.Vec3(body.position.x, body.position.y - PLAYER_RADIUS - 0.2, body.position.z);
    const result = new CANNON.RaycastResult();
    world.raycastClosest(from, to, { collisionFilterMask: GROUP.DEFAULT | GROUP.RAGDOLL }, result);
    return result.hasHit;
  }

  const UP = new THREE.Vector3(0, 1, 0);
  function update(dt) {
    const locked = document.pointerLockElement === domElement;
    grounded = checkGrounded();

    camera.rotation.order = 'YXZ';
    camera.rotation.y = euler.yaw;
    camera.rotation.x = euler.pitch;

    const forward = new THREE.Vector3();
    camera.getWorldDirection(forward);
    forward.y = 0;
    if (forward.lengthSq() < 1e-6) forward.set(0, 0, -1);
    forward.normalize();
    const right = new THREE.Vector3().crossVectors(forward, UP);

    const moveDir = new THREE.Vector3();
    if (locked) {
      if (keys.forward) moveDir.add(forward);
      if (keys.back) moveDir.sub(forward);
      if (keys.right) moveDir.add(right);
      if (keys.left) moveDir.sub(right);
    }
    if (moveDir.lengthSq() > 0) moveDir.normalize();

    const speed = WALK_SPEED * (keys.sprint ? SPRINT_MULT : 1);
    const targetVX = moveDir.x * speed;
    const targetVZ = moveDir.z * speed;
    // Exponential smoothing based on actual elapsed time, not on how many
    // update() calls happen to occur. The old version applied a fixed
    // fraction of the gap toward the target speed once per rendered frame,
    // which meant acceleration was tied to frame rate: fine at 60fps, but
    // if the frame rate ever degrades (more objects in the scene, a
    // longer session), the same correction happens far less often per
    // real second and movement gets progressively mushier, exactly what
    // "can't walk after a while" was. This reaches the same speed in the
    // same real time regardless of frame rate.
    const rate = grounded ? RESPONSE_RATE_GROUNDED : RESPONSE_RATE_AIR;
    const factor = 1 - Math.exp(-rate * dt);
    body.velocity.x += (targetVX - body.velocity.x) * factor;
    body.velocity.z += (targetVZ - body.velocity.z) * factor;

    if (jumpQueued && grounded && locked) {
      body.velocity.y = JUMP_SPEED;
    }
    jumpQueued = false;

    speedFrac = Math.min(1, Math.hypot(body.velocity.x, body.velocity.z) / (WALK_SPEED * SPRINT_MULT));

    camera.position.set(body.position.x, body.position.y + EYE_HEIGHT, body.position.z);
  }

  function teleport(pos) {
    body.position.set(pos.x, pos.y, pos.z);
    body.velocity.set(0, 0, 0);
  }

  function dispose() {
    document.removeEventListener('mousemove', onMouseMove);
    document.removeEventListener('keydown', onKeyDown);
    document.removeEventListener('keyup', onKeyUp);
  }

  return {
    body,
    update,
    teleport,
    dispose,
    get grounded() {
      return grounded;
    },
    get speedFrac() {
      return speedFrac;
    },
    get yaw() {
      return euler.yaw;
    },
  };
}
