import { WEAPONS } from './weapons.js';
import { SPAWNERS, spawnerCooldownFrac } from './spawners.js';

const ITEMS = [...WEAPONS, ...SPAWNERS];
const CATEGORY_LABEL = { gun: 'GUNS', melee: 'MELEE', explosive: 'EXPLOSIVES', spawn: 'SPAWN' };
const CATEGORY_KEY = { Digit1: 'gun', Digit2: 'melee', Digit3: 'explosive', Digit4: 'spawn' };
const CATEGORY_ORDER = ['gun', 'melee', 'explosive', 'spawn'];

export function createUI({ onStart, onSelectWeapon, onSpawn }) {
  const el = (id) => document.getElementById(id);

  const startScreen = el('start-screen');
  const pauseScreen = el('pause-screen');
  const hud = el('hud');
  const hotbar = el('hotbar');
  const ammoName = el('ammo-name');
  const ammoCount = el('ammo-count');
  const ammoBarFill = el('ammo-bar-fill');
  const crosshair = el('crosshair');
  const scopeOverlay = el('scope-overlay');
  const hitmarker = el('hitmarker');
  const toastBox = el('toast');
  const spawnMenu = el('spawn-menu');
  const fpsCounter = el('fps-counter');
  const detonateHint = el('detonate-hint');

  let selectedCategory = 'gun';
  let selectedId = 'pistol';

  // ---- hotbar ----
  const KEY_NUM = { gun: '1', melee: '2', explosive: '3', spawn: '4' };
  function buildHotbar() {
    hotbar.innerHTML = '';
    for (const cat of CATEGORY_ORDER) {
      const group = document.createElement('div');
      group.className = 'hotbar-group';
      const label = document.createElement('div');
      label.className = 'hotbar-group-label';
      label.textContent = `[${KEY_NUM[cat]}] ${CATEGORY_LABEL[cat]}`;
      group.appendChild(label);
      const row = document.createElement('div');
      row.className = 'hotbar-row';
      ITEMS.filter((w) => w.category === cat).forEach((w) => {
        const slot = document.createElement('button');
        slot.className = 'hotbar-slot';
        slot.dataset.id = w.id;
        slot.textContent = w.name;
        slot.addEventListener('click', () => selectWeapon(w.id));
        row.appendChild(slot);
      });
      group.appendChild(row);
      hotbar.appendChild(group);
    }
    refreshHotbarHighlight();
  }

  function refreshHotbarHighlight() {
    hotbar.querySelectorAll('.hotbar-slot').forEach((s) => {
      s.classList.toggle('active', s.dataset.id === selectedId);
    });
  }

  function selectWeapon(id) {
    const w = ITEMS.find((x) => x.id === id);
    if (!w) return;
    selectedId = id;
    selectedCategory = w.category;
    refreshHotbarHighlight();
    ammoName.textContent = w.name;
    detonateHint.classList.toggle('visible', w.remote === true);
    onSelectWeapon(w);
  }

  function cycleCategory(catCode) {
    const cat = CATEGORY_KEY[catCode];
    if (!cat) return;
    if (selectedCategory === cat) {
      // same key pressed again: advance to next item in this category
      const list = ITEMS.filter((w) => w.category === cat);
      const idx = list.findIndex((w) => w.id === selectedId);
      selectWeapon(list[(idx + 1) % list.length].id);
    } else {
      const first = ITEMS.find((w) => w.category === cat);
      selectWeapon(first.id);
    }
  }

  function scrollCycle(dir) {
    const list = ITEMS.filter((w) => w.category === selectedCategory);
    const idx = list.findIndex((w) => w.id === selectedId);
    const next = (idx + dir + list.length) % list.length;
    selectWeapon(list[next].id);
  }

  buildHotbar();
  selectWeapon('pistol');

  // ---- ammo / gun state readout ----
  function updateWeaponState(weapon, state, time) {
    if (weapon.category === 'gun') {
      ammoCount.textContent = state.reloading ? 'RELOADING' : `${state.ammo} / ${weapon.magSize}`;
      const frac = state.reloading ? Math.min(1, (time - (state.reloadEndsAt - weapon.reloadTime)) / weapon.reloadTime) : 1;
      ammoBarFill.style.width = `${Math.round(frac * 100)}%`;
      ammoBarFill.classList.toggle('reloading', state.reloading);
    } else if (weapon.category === 'melee') {
      const cd = Math.max(0, weapon.swingTime - (time - state.lastSwing));
      ammoCount.textContent = cd > 0.02 ? 'SWINGING' : 'READY';
      ammoBarFill.style.width = `${Math.round((1 - cd / weapon.swingTime) * 100)}%`;
      ammoBarFill.classList.remove('reloading');
    } else if (weapon.category === 'spawn') {
      const frac = spawnerCooldownFrac(weapon.id, time);
      ammoCount.textContent = frac >= 1 ? 'READY' : 'RECHARGING';
      ammoBarFill.style.width = `${Math.round(frac * 100)}%`;
      ammoBarFill.classList.remove('reloading');
    } else {
      ammoCount.textContent = weapon.remote ? 'REMOTE ARMED' : 'ARMED ON THROW';
      ammoBarFill.style.width = '100%';
      ammoBarFill.classList.remove('reloading');
    }
  }

  // ---- start / pause ----
  function showStart() {
    startScreen.classList.remove('hidden');
    hud.classList.add('hidden');
  }
  function hideStart() {
    startScreen.classList.add('hidden');
    hud.classList.remove('hidden');
  }
  function showPause() {
    pauseScreen.classList.remove('hidden');
  }
  function hidePause() {
    pauseScreen.classList.add('hidden');
  }

  startScreen.querySelector('#start-btn').addEventListener('click', onStart);
  pauseScreen.querySelector('#resume-btn').addEventListener('click', onStart);

  // ---- hit feedback ----
  let hitTimeout = null;
  function flashHit() {
    hitmarker.classList.add('show');
    clearTimeout(hitTimeout);
    hitTimeout = setTimeout(() => hitmarker.classList.remove('show'), 110);
  }

  // ---- toasts ----
  let toastTimeout = null;
  function toast(text) {
    toastBox.textContent = text;
    toastBox.classList.add('show');
    clearTimeout(toastTimeout);
    toastTimeout = setTimeout(() => toastBox.classList.remove('show'), 2200);
  }

  // ---- spawn menu ----
  let spawnMenuOpen = false;
  function toggleSpawnMenu() {
    spawnMenuOpen = !spawnMenuOpen;
    spawnMenu.classList.toggle('hidden', !spawnMenuOpen);
    return spawnMenuOpen;
  }
  spawnMenu.querySelectorAll('[data-spawn]').forEach((btn) => {
    btn.addEventListener('click', () => onSpawn(btn.dataset.spawn));
  });

  // ---- fps ----
  let frames = 0;
  let lastFpsUpdate = performance.now();
  function tickFps() {
    frames++;
    const now = performance.now();
    if (now - lastFpsUpdate > 500) {
      fpsCounter.textContent = `${Math.round((frames * 1000) / (now - lastFpsUpdate))} FPS`;
      frames = 0;
      lastFpsUpdate = now;
    }
  }

  document.addEventListener('keydown', (e) => {
    if (e.code in CATEGORY_KEY) cycleCategory(e.code);
    if (e.code === 'Tab') {
      e.preventDefault();
      toggleSpawnMenu();
    }
  });
  document.addEventListener('wheel', (e) => {
    if (document.pointerLockElement) scrollCycle(e.deltaY > 0 ? 1 : -1);
  });

  function setAiming(isAiming, isScoped) {
    crosshair.classList.toggle('aiming', isAiming && !isScoped);
    crosshair.classList.toggle('hidden', isScoped);
    scopeOverlay.classList.toggle('active', isScoped);
  }

  return {
    showStart,
    hideStart,
    showPause,
    hidePause,
    updateWeaponState,
    flashHit,
    toast,
    tickFps,
    setAiming,
    get selectedId() {
      return selectedId;
    },
    get spawnMenuOpen() {
      return spawnMenuOpen;
    },
  };
}
