import * as THREE from 'three';
import * as CANNON from 'cannon-es';
import { RoomEnvironment } from 'three/examples/jsm/environments/RoomEnvironment.js';
import { EffectComposer } from 'three/examples/jsm/postprocessing/EffectComposer.js';
import { RenderPass } from 'three/examples/jsm/postprocessing/RenderPass.js';
import { UnrealBloomPass } from 'three/examples/jsm/postprocessing/UnrealBloomPass.js';

import { createPhysicsWorld, stepWorld } from './physics.js';
import { buildWorld, updateWaterZones } from './world.js';
import { createPlayer } from './player.js';
import { createViewmodel } from './viewmodel.js';
import { initEffects, updateEffects } from './effects.js';
import { syncMeshes } from './props.js';
import { spawnCrate, spawnBarrel, spawnPlank, spawnTarget } from './props.js';
import { createDummy, updateDummy, allDummies } from './dummy.js';
import { SPAWNERS, trySpawn } from './spawners.js';
import { WEAPONS, createWeaponRuntime, fireGun, swingMelee, throwExplosive, updateGun, updateExplosives, detonateAllRemote, startReload } from './weapons.js';
import { createUI } from './ui.js';

const canvas = document.getElementById('scene');
const renderer = new THREE.WebGLRenderer({ canvas, antialias: true, powerPreference: 'high-performance' });
renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
renderer.setSize(window.innerWidth, window.innerHeight);
renderer.shadowMap.enabled = true;
renderer.shadowMap.type = THREE.PCFSoftShadowMap;
renderer.outputColorSpace = THREE.SRGBColorSpace;
renderer.toneMapping = THREE.ACESFilmicToneMapping;
renderer.toneMappingExposure = 1.05;

const scene = new THREE.Scene();
const camera = new THREE.PerspectiveCamera(78, window.innerWidth / window.innerHeight, 0.05, 300);
// The viewmodel hand/weapon is parented to the camera (see viewmodel.js). The
// renderer builds its draw list by traversing `scene`, so unless the camera
// itself is part of that scene graph, anything hanging off it never renders,
// even though its matrices update correctly. This was the bug: the hand
// existed and was positioned correctly, it was just structurally invisible.
scene.add(camera);

const pmrem = new THREE.PMREMGenerator(renderer);
scene.environment = pmrem.fromScene(new RoomEnvironment(), 0.04).texture;

const world = createPhysicsWorld();
const { stations, waterZones, spawnPoint } = buildWorld(world, scene);

const player = createPlayer(world, camera, renderer.domElement, new CANNON.Vec3(spawnPoint.x, spawnPoint.y, spawnPoint.z));
const viewmodel = createViewmodel(camera);
initEffects(scene);
const weaponState = createWeaponRuntime();

const composer = new EffectComposer(renderer);
composer.addPass(new RenderPass(scene, camera));
const bloom = new UnrealBloomPass(new THREE.Vector2(window.innerWidth, window.innerHeight), 0.55, 0.5, 0.86);
composer.addPass(bloom);

let currentWeapon = WEAPONS.find((w) => w.id === 'pistol');
viewmodel.setWeapon(currentWeapon);

let started = false;
let clockTime = 0;
let mouseHeld = false;
let rightMouseHeld = false;
let currentStationIndex = -1;
const BASE_FOV = 78;
const ADS_FOV = 62;
const ZOOM_FOV = 28;

canvas.addEventListener('contextmenu', (e) => e.preventDefault());

const ui = createUI({
  onStart: () => {
    const requestLock = () => {
      const lockResult = renderer.domElement.requestPointerLock();
      if (lockResult && typeof lockResult.catch === 'function') lockResult.catch(() => {});
    };
    if (!document.fullscreenElement) {
      const fsResult = document.documentElement.requestFullscreen();
      if (fsResult && typeof fsResult.then === 'function') {
        // Entering fullscreen is a document-level transition; requesting
        // pointer lock at the exact same moment (rather than after it
        // settles) can cause the lock to be granted and then immediately
        // dropped, which silently breaks every control gated behind it
        // (movement, jumping, firing) with no visible error.
        fsResult.then(requestLock).catch(requestLock);
      } else {
        requestLock();
      }
    } else {
      requestLock();
    }
  },
  onSelectWeapon: (weapon) => {
    currentWeapon = weapon;
    viewmodel.setWeapon(weapon);
  },
  onSpawn: (kind) => {
    const mappedKind = kind === 'ragdoll' ? 'dummy' : kind;
    const spawner = SPAWNERS.find((s) => s.kind === mappedKind);
    if (spawner) trySpawn(spawner, buildContext());
  },
});

function buildContext() {
  return {
    world,
    scene,
    camera,
    state: weaponState,
    time: clockTime,
    playerBody: player.body,
    viewmodel,
  };
}

function handlePrimary() {
  if (!started) return;
  const ctx = buildContext();
  if (currentWeapon.category === 'gun') {
    const result = fireGun(currentWeapon, ctx);
    if (result && result.hit) ui.flashHit();
  } else if (currentWeapon.category === 'melee') {
    const hit = swingMelee(currentWeapon, ctx);
    if (hit) ui.flashHit();
  } else if (currentWeapon.category === 'spawn') {
    trySpawn(currentWeapon, ctx);
  } else {
    throwExplosive(currentWeapon, ctx);
  }
}

document.addEventListener('mousedown', (e) => {
  if (document.pointerLockElement !== renderer.domElement) return;
  if (e.button === 0) {
    mouseHeld = true;
    handlePrimary();
  }
  if (e.button === 2) rightMouseHeld = true;
});
document.addEventListener('mouseup', (e) => {
  if (e.button === 0) mouseHeld = false;
  if (e.button === 2) rightMouseHeld = false;
});
document.addEventListener('keydown', (e) => {
  if (document.pointerLockElement !== renderer.domElement) return;
  if (e.code === 'KeyR' && currentWeapon.category === 'gun') {
    startReload(currentWeapon, buildContext());
  }
  if (e.code === 'KeyF' && currentWeapon.remote) {
    detonateAllRemote(currentWeapon.id, buildContext());
  }
});

document.addEventListener('pointerlockchange', () => {
  if (document.pointerLockElement === renderer.domElement) {
    started = true;
    ui.hideStart();
    ui.hidePause();
  } else if (started) {
    ui.showPause();
    mouseHeld = false;
    rightMouseHeld = false;
  }
});

window.addEventListener('resize', () => {
  camera.aspect = window.innerWidth / window.innerHeight;
  camera.updateProjectionMatrix();
  renderer.setSize(window.innerWidth, window.innerHeight);
  composer.setSize(window.innerWidth, window.innerHeight);
  bloom.setSize(window.innerWidth, window.innerHeight);
});

function checkStationProximity() {
  const p = player.body.position;
  let closest = -1;
  let closestDist = 9;
  stations.forEach((s, i) => {
    const d = Math.hypot(p.x - s.origin.x, p.z - s.origin.z);
    if (d < closestDist) {
      closestDist = d;
      closest = i;
    }
  });
  if (closest !== -1 && closest !== currentStationIndex) {
    currentStationIndex = closest;
    ui.toast(`Station ${stations[closest].index} / ${stations.length}: ${stations[closest].name}`);
  }
}

const clock = new THREE.Clock();
let stationCheckAccum = 0;

function animate() {
  requestAnimationFrame(animate);
  const dt = Math.min(clock.getDelta(), 0.1);
  clockTime += dt;

  if (started) {
    stepWorld(world, dt);
    player.update(dt);

    if (mouseHeld && currentWeapon.category === 'gun' && currentWeapon.auto) {
      const result = fireGun(currentWeapon, buildContext());
      if (result && result.hit) ui.flashHit();
    }

    for (const w of WEAPONS) {
      if (w.category === 'gun') updateGun(w, { state: weaponState, time: clockTime });
    }
    updateExplosives(buildContext());
    for (const dummy of allDummies()) updateDummy(dummy, clockTime);
    updateWaterZones(waterZones, dt);
    syncMeshes();
    updateEffects(dt);
    viewmodel.update(dt, { speed: player.speedFrac, grounded: player.grounded });

    stationCheckAccum += dt;
    if (stationCheckAccum > 0.4) {
      stationCheckAccum = 0;
      checkStationProximity();
    }

    const isAiming = rightMouseHeld && currentWeapon.category === 'gun';
    const isScoped = isAiming && currentWeapon.scope === true;
    viewmodel.setAiming(isAiming);
    viewmodel.setHidden(isScoped);
    ui.setAiming(isAiming, isScoped);

    const targetFov = isScoped ? ZOOM_FOV : isAiming ? ADS_FOV : BASE_FOV;
    if (Math.abs(camera.fov - targetFov) > 0.05) {
      camera.fov += (targetFov - camera.fov) * Math.min(1, dt * 10);
      camera.updateProjectionMatrix();
    }

    ui.updateWeaponState(currentWeapon, weaponState[currentWeapon.id], clockTime);
  } else {
    player.update(0);
  }

  ui.tickFps();
  composer.render();
}

animate();
