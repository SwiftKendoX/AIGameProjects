PROVING GROUNDS
A first person physics sandbox
================================

HOW TO LAUNCH
-------------
Double click Play.exe. It opens the game in your default browser and
requests fullscreen once you click "Enter Facility" inside the game
(browsers only allow fullscreen after a real click, so that first click
is required, it can't be skipped).

If Windows shows a blue "Windows protected your PC" SmartScreen screen the
first time you run Play.exe: that is standard for any small unsigned exe,
not a sign anything is broken. Click "More info" then "Run anyway".

If you'd rather not run the exe at all, you can just double click
index.html directly, same result.

CONTROLS
--------
  WASD          Move
  Mouse         Look
  Space         Jump
  Shift         Sprint
  1 / 2 / 3 / 4  Switch to Guns / Melee / Explosives / Spawn tools
  Scroll wheel  Cycle items within the current category
  Left click    Fire / swing / throw / spawn (whatever is equipped)
  R             Reload
  F             Detonate all placed Remote C4
  Right click   Aim down sights (any gun); full scope zoom on the Sniper
  Tab           Open the spawn menu (same spawns as the Spawn category, as buttons)
  Esc           Release the cursor / pause

DUMMIES
-------
Equip a dummy the same way you'd equip a gun (press 4, click), and aim
where you want it to appear. Dummies stand on their own. Any hit, gun,
melee, or explosion, immediately and fully ragdolls them with zero
resistance. If they're still alive, they stand back up on their own a few
seconds after things settle down. Once their health runs out, they stay
down for good.

WHAT'S INSIDE
-------------
10 stations, laid out around the central spawn point:
  1. Shooting Range     6. Sand Pit
  2. Ragdoll Arena      7. Block Tower
  3. Melee Dojo         8. Drop Zone
  4. Demolition Pit     9. Launch Seesaw
  5. Liquid Pool        10. Junkyard

15 weapons on 3 shared systems:
  Guns (hitscan):     Pistol, SMG, Shotgun, Rifle, Sniper
  Melee (swing):       Bat, Crowbar, Machete, Sledgehammer, Knife
  Explosives (thrown): Grenade, Dynamite, Remote C4, Pipe Bomb, Sticky Bomb

Ragdoll dummies use real jointed rigid body physics (11 parts, ball joints
at the shoulders/hips/neck/waist, hinges at the elbows/knees), and barrels
chain react when destroyed near each other.

THE /source FOLDER
-------------------
Full readable, editable source is included (not just the bundled game),
since you'll probably want to tweak or extend this yourself:

  cd source
  npm install
  npm run build      -> rebuilds bundle.js from src/
  npm test            -> runs the automated physics/weapon test suite

The physics, ragdoll and dummy code has zero rendering dependencies, so
the full test suite (7 files, 223 checks covering ragdoll physics, all 15
weapons, movement, the dummy state machine, spawn placement and caps, aim
down sights, and the scene graph) runs in plain Node and actually
simulates the game against real physics bodies, that's how this was
verified before shipping to you.

CHANGELOG
---------
v1.3: Movement acceleration was tied to frame rate rather than real time,
meaning it got progressively less responsive the longer a session ran or
the more got spawned, which is what "can't walk after a while" actually
was. It's now computed from elapsed time directly, so it behaves the same
regardless of frame rate. Also closed the actual reason frame rate could
degrade over a session: crates, barrels, targets and planks spawned
through the Spawn tool had no cap at all (only dummies did), so they could
accumulate without limit; all spawned props are now capped the same way,
oldest evicted first. Fixed dummies feeling anchored while standing: the
standing assist previously never turned off even once a dummy was already
correctly upright, so bumping into one just got fought back to the exact
same spot. It now only engages when there's an actual error to correct,
which took two attempts to get right, the first version of that fix
accidentally let the safety speed cap get skipped in the same case, caught
that with a direct measurement before shipping it. Added aim down sights
for every gun (weapon centers on screen, steadies) plus a real scope
overlay with reticle for the Sniper specifically, rather than only a
narrower field of view.

v1.2: Fixed the real cause of the violent "everything teleports" bug, which
was actually two separate things. First, spawning a dummy (or any prop) at
a position overlapping the player, easy to trigger by aiming down while
using the new Spawn tool, made the physics engine forcibly and instantly
push them apart, which reads as a teleport. Spawning now always keeps a
safe minimum distance from wherever you're standing, regardless of aim
angle. Second, the dummy standing-back-up force was tuned by only checking
where it ended up, not how violently it got there. It's now checked
against a hard, always-on speed cap on every single body part, not just
some of them, so a future tuning mistake here can't do this again, and the
underlying force was also redesigned to actually lift every limb (the
first version stalled partway because legs left flat on the ground had
nothing helping them up).

v1.1: Fixed the viewmodel hand being invisible (the camera holding it was
never added to the scene graph, so it never rendered even though it was
built and positioned correctly). Fixed movement being capped to roughly a
third of its intended speed by ground friction fighting the movement code.
Fixed the pipe bomb's bounciness silently doing nothing. Added dummies as
a proper Spawn category tool (aim and click, like a gun) instead of only
being in the Tab menu. Redesigned dummies with a warning sign figure look
and a real standing/ragdoll/recovery state machine.

HONEST NOTES ON SCOPE
----------------------
This is realtime PBR shading (dynamic shadows, reflections via an
environment map, bloom, ACES tone mapping), not literal ray tracing.
Genuine RTX style ray tracing needs a native engine (Unreal/Unity) and a
GPU pipeline this browser based build doesn't have access to. If you want
to push toward that level later, the C# side of your Unity drift game
project is the more direct path, happy to help port systems over if
you want that.

Performance is tuned for a GTX 1650 class laptop. If it chugs, lowering
the browser window size or closing other GPU heavy tabs helps most,
since this renders through the browser's WebGL stack.
